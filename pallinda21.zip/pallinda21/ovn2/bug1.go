//Debug deadlocks
//Occurs when a group of goroutines are waiting for each other
//and none of them is able to proceed

package main

import "fmt"

func main() {
	ch := make(chan string)

	//Send message, spawn one more goroutine
	go func() { //Väntar på att någon ska läsa från kanalen. Måste finnas någon som skickar samtidigt..
		ch <- "Hello world!"
		close(ch) //The close function records that no more values will be sent on a channel.
	}()

	//Recieve message
	//<-ch blockar till sändaren är klar
	fmt.Println(<-ch)
}

/*Alternative solution discussed on lecture
package main
import "fmt"

func main() {
ch := make(chan string, 1)
ch <- "Hello world!" //The program will get stuck on the channel send operation waiting forever for someone to read the value.
close()
fmt.Println(<-ch)
}
*/

//####BUG 1 - HOW IT INITIALLY LOOKED LIKE####
/*
	fatal error: all goroutines are asleep - deadlock!

	goroutine 1 [chan send]:
	main.main()
	/Users/Jesper/Documents/pallinda21/ovn2/bug1.go:40 +0x37
	exit status 2
*/
/*
package main

import "fmt"

// I want this program to print "Hello world!", but it doesn't work.
func main() {
	ch := make(chan string)
	ch <- "Hello world!" //Väntar på att någon ska läsa från kanalen. Måste finnas någon som tar emot..
	fmt.Println(<-ch)
}
*/
