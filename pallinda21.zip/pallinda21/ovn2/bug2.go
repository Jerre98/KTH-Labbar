//https://yourbasic.org/golang/wait-for-goroutines-waitgroup/
package main

import (
	"fmt"
	"sync"
)

//First the main goroutine calls Add to set the number of goroutines to wait for.
func main() {
	ch := make(chan int)
	wg := new(sync.WaitGroup)
	wg.Add(1) //Add a count of 1, for our goroutine.

	go Print(ch, wg) //Pass ch and pass this waitgroup to the Print goroutine.

	for i := 1; i <= 11; i++ {
		ch <- i
	}
	close(ch)
	wg.Wait() //Wait for our Print goroutine to finish (in our case we wait for wg.Done()).

}

// Print prints all numbers sent on the channel.
// The function returns when the channel is closed.
func Print(ch <-chan int, wg *sync.WaitGroup) {
	for n := range ch { // reads from channel until it's closed
		fmt.Println(n)
	}
	wg.Done() //we call .Done() within our Print goroutine to signal that print process is done.

	//Each done is a -1 to the counter
}

//Programmet bör komma till 11, men ibland printar den bara fram till 10...
/*
Problemet verkar bero på:
- Att main tråden returnerar innan alla värden har printas
och således kan print 11 ibland utelämnas..

SOLUTION
	- Use sync libraries WaitGroup to signal when Print function is done
	- Declare wg.Wait() at end of main, which will wait until wg.Done()


*/

/*
//####BUG 2 - HOW IT INITIALLY LOOKED LIKE####

package main

import "fmt"

// This program should go to 11, but sometimes it only prints 1 to 10.
func main() {
	ch := make(chan int)
	go Print(ch)
	for i := 1; i <= 11; i++ {
		ch <- i
	}
	close(ch)
}

// Print prints all numbers sent on the channel.
// The function returns when the channel is closed.
func Print(ch <-chan int) {
	for n := range ch { // reads from channel until it's closed
		fmt.Println(n)
	}
}
*/
