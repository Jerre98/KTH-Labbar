//TASK 3 ALARM CLOCK
//Magical date, time: https://programming.guide/go/format-parse-string-time-date-example.html
package main

import (
	"fmt"
	"time"
)

func Remind(text string, delay time.Duration) { //channelOut chan string

	//Run for-loop with select to identify what case/timer channel and return appropriate strings
	for {
		time.Sleep(delay)
		//case <-caseTimer.C: //We have three different cases: 3, 8 and 24
		currentlocalTime := time.Now() //Now() returns the current local time.
		//XX.XX should be replaced with the current time, and <text> should be replaced by the contents of text.
		//%d integer base 10, %s the uninterpreted bytes of the string
		currentString := fmt.Sprintf("Klockan är: "+"%d.%d.%d"+": "+"%s"+"\n", currentlocalTime.Hour(), currentlocalTime.Minute(), currentlocalTime.Second(), text)

		fmt.Println(currentString)
	}
}

func main() {
	//channelOut := make(chan string) //Channels must be created before use
	initialTime := time.Now() //Now returns the current local time, at start we want the current local time.

	fmt.Println("Current start time when executing: ", initialTime.Format("15:04:05")) //magical date: we see that no two fields are the same. This means that for this particular date, each field can be identified unambigously regardless of the formatting.
	//Magical date and time will give us the current day and current time today

	//We have 3 different concurrent goroutines running and these will send to a channel
	//(text, delay)
	go Remind("Dags att äta", 3*time.Hour)    //channelOut)    //Use "Second" instead of "Hour" to illustrate to user.
	go Remind("Dags att arbeta", 8*time.Hour) //goroutines are go's mechanism for running code concurrently
	go Remind("Dags att sova", 24*time.Hour)
	select {}
	//I'm using for and range to iterate over values recieved from channelOut.
	//for elem := range channelOut { //This range iterates over each element as it's recieved from channelOut. We do not close the channel above, and thus the iteration will not terminate after receving a specified number of elements...
	//	fmt.Print(elem)
	//}

}
