package main

import "golang.org/x/tour/pic"

//Choice of image is up to you, interesting functions include (x+y)/2, x*y and x^y
func Pic(dx, dy int) [][]uint8 {//uint8 heltal till 255.
	//dx and dy are both set to a constant of 256. In the example code given, in the for range, only the index is used as slide data
	//Create initial slice, it must have dy elements of type []uint8
	pic := make([][]uint8, dy)//use make to create slice of length dy
	for y := range pic {
		//Add the dx elements to each elemnt of the initial slice
		for x := 0; x < dx; x++ {
			pic[y] = append(pic[y], uint8(x*y))
		}

	}
	return pic //return the slice

}

func main() {
	pic.Show(Pic) //In the example, if we create [][]uint8 data containing a slice []unit8 in a slice[]
	//and give it to Show() of the Pic package, it will give us a certain bluescale graphic.
}
