package main

/*
Implement WordCount. It should return a map of the counts of each “word” in the string s.
The wc.Test function runs a test suite against the provided function and prints success or failure.
*/

import (
	"strings"

	"golang.org/x/tour/wc"
)

func WordCount(s string) map[string]int {
	m := make(map[string]int)    //Find the map that we're going to return
	words := strings.Fields(s)   //Fields splits the string s around each instance of one or more consecutive white space characters
	for _, word := range words { //We don't care about the index, we only care about the value.. The blank identifier _ is an anonymous placeholder.
		//It may be used like any other identifier in a declaration, but it does not introduce a binding.
		m[word] += 1
	}
	return m
}
func main() {
	wc.Test(WordCount)
}
