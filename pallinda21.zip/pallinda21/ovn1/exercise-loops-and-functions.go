package main

import (
	"fmt"
	"math"
)

func Sqrt(x float64) float64 {
	//x is our input (float64)
	//z will represent our guess (also float64)
	z := float64(1)
	//i := 0; i < 10; i++
	err := 0.000000001
	zBeg := float64(0)
	for (math.Abs(z - zBeg)) > err {
		zBeg = z
		z -= (z*z - x) / (2 * z)
		fmt.Println(z)
		//if z == Sqrt(x) - if we use 10 iterations and Sqrt(2) it will break at 4th or 5th iteration

	}
	return z
}

func main() {
	number := float64(4)
	z_guess := Sqrt(number)
	actual := math.Sqrt(number)        //inbuilt function math
	diff := math.Abs(z_guess - actual) //Only used in part1..
	fmt.Println("Number ", number, "Guess ", z_guess, "Actual", actual, "Diff ", diff)
}
