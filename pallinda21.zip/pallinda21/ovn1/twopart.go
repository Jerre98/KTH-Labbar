// TASK 4 Two Part Sum
/*In this task you will complete the following partial program.
It adds all of the numbers in an array by splitting the array in half,
then having two Go routines take care of each half. Partial results are then sent over a channel.
Remember to test and format your code.
*/
package main

import "fmt"

// Add adds the numbers in a and sends the result on res.
func Add(a []int, res chan<- int) {
	// TODO
	sum := 0
	for j := range a {
		sum += a[j]
	}
	res <- sum
}

func main() {
	a := []int{1, 2, 3, 4, 5, 6, 7}
	n := len(a)
	ch := make(chan int)
	go Add(a[:n/2], ch)
	go Add(a[n/2:], ch)

	// TODO: Get the subtotals from the channel and print their sum.
	total := <-ch + <-ch
	fmt.Println(total)
}
