SELECT Name as CountryName, Area, Population
FROM Country
WHERE Population < 1000;
