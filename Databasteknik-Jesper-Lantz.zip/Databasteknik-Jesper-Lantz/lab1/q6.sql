SELECT Name, Population, Elevation
FROM City
WHERE Elevation < 0;
