SELECT Name
FROM City
WHERE Country = “S” AND Population >500000;
