SELECT Country.Name, City.Name, City.Elevation
FROM City, Country
WHERE Country=Country.Code AND City.Elevation IS NOT NULL
ORDER by City.Elevation ASC LIMIT 5;