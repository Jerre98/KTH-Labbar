SELECT Name, Population, Are
FROM Country
WHERE Population < 2000 AND Population > 1000 AND Area >= 1;
