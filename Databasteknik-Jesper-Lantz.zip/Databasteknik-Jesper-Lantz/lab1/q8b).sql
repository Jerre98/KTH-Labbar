SELECT Name
FROM City
WHERE (Name LIKE "Los%" OR Name LIKE "%holm")
AND NAME NOT LIKE "%is";