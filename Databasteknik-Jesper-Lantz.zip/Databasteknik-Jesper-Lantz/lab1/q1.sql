SELECT Name
FROM Country
WHERE Population < 1000;
