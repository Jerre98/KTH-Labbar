SELECT Code
FROM Country
WHERE Name = “Norway”;
