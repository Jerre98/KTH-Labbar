

SELECT * FROM Country;