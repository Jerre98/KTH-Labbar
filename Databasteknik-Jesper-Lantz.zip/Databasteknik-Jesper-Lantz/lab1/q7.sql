SELECT SUM(Population) as total, 
AVG(Population) as average, 
MIN(Population) as minimum, 
Max(Population) as maximum
FROM City
WHERE Elevation < 0;