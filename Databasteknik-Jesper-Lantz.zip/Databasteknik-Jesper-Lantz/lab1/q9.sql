SELECT Name, Population
FROM Country
ORDER BY Population DESC LIMIT 5;
