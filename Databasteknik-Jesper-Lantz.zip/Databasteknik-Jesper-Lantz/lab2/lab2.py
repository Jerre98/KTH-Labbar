#!/usr/bin/python

#Lab2 DD1334: Jesper Lantz 981228-2417, Theodor Günther
import sqlite3
from sys import argv
import matplotlib.pyplot as plt
import numpy as np
from sklearn.linear_model import LinearRegression

class Program:
    def __init__(self): #PG-connection setup
        self.conn = sqlite3.connect('mondial.db') # establish database connection
        self.cur = self.conn.cursor() # create a database query cursor

        # specify the command line menu here
        self.actions = [self.population_query, 
                        self.scatterplot1,
                        self.scatterplot2,
                        self.regressionplot,
                        self.linearprediction_allcities,
                        self.prediction_q2e,
                        self.prediction_q2f,
                        self.hypothesis,
                        self.exit]
        # menu text for each of the actions above
        self.menu = ["Population Query", 
                    "Plot of the raw yearly population data for all cities",
                    "Plot of the yearly sum of population of all cities",
                    "Linear regression bla bla bla....",
                    "Linear prediction blablalbl.a...",
                    "Predictions for each year from 1950 to 2050 of population trends",
                    "Prediction table",
                    "Hypothesis",
                    "Exit"]
        self.cur = self.conn.cursor()
    def print_menu(self):
        """Prints a menu of all functions this program offers.  Returns the numerical correspondant of the choice made."""
        for i,x in enumerate(self.menu):
            print("%i. %s"%(i+1,x))
        return self.get_int()
    def get_int(self):
        """Retrieves an integer from the user.
        If the user fails to submit an integer, it will reprompt until an integer is submitted."""
        while True:
            try:
                choice = int(input("Choose: "))
                if 1 <= choice <= len(self.menu):
                    return choice
                print("Invalid choice.")
            except (NameError,ValueError, TypeError,SyntaxError):
                print("That was not a number, genious.... :(")
 
    def population_query(self):
        minpop = input("min_population: ")
        maxpop = input("max_population: ")
        print("minpop: %s, maxpop: %s" % (minpop, maxpop))
        try:
            query ="SELECT * FROM city WHERE population >=%s AND population <= %s" % (minpop, maxpop)
            print("Will execute: ", query)
            result = self.cur.fetchall()
            self.cur.execute(query)
        except sqlite3.Error as e:
            print ("Error message:", e.args[0])
            connection1.rollback()
            exit()

        self.print_answer(result)

    def exit(self):    
        self.cur.close()
        self.conn.close()
        exit()

    def print_answer(self, result):
        print("-----------------------------------")
        for r in result:
            print(r)
        print("-----------------------------------")


    
    def run(self):
        while True:
            try:
                self.actions[self.print_menu()-1]()
            except IndexError:
                print("Bad choice")
                continue

    def drop(self, table):
    # delete the table XYData if it does already exist
        try:
            query = "DROP TABLE " + table + ';'
            self.cur.execute(query)
            self.conn.commit()  
        except:
            print( table + " table does not exists")
            pass


############ Self-made functions ############

    def scatterplot1(self): #2(a)
        year = []
        population = []
        query = "SELECT Year, Population " \
                "FROM Citypops ;"
        print("Will execute: ", query)
        self.cur.execute(query) #Execute a SQL statement (the query)
        result = self.cur.fetchall() #Fetches all rows from the resultset

        for r in result:
            # you access ith component of row r with r[i], indexing starts with 0
            # check for null values represented as "None" in python before conversion and drop
            # row whenever NULL occurs
            print("Considering tuple", r)
            if (r[0] != None and r[1] !=None): 
                year.append(int(r[0]))
                population.append(int(r[1]))

            else:
                print("Dropped tuple ", r) 
        
        print("Year:", year)
        print("Population:", population)
        plt.scatter(year, population) #Scatter plot för year (x) och population (y)
        
        query2 = "SELECT city, population " \
        "FROM Citypops GROUP BY city ORDER BY population DESC LIMIT 10 ;"
        print ("Will execute: ", query2)
        self.cur.execute(query2)                 # first execute the query
        data = self.cur.fetchall()
        self.print_answer(data)
        
        plt.title("City population raw data")
        plt.xlabel("Year interval")
        plt.ylabel("Population data")
        plt.show()# display figure if you run this code locally, otherwise comment out
        return

    def scatterplot2(self): #2(b)
        year = []
        population = []
        query = "SELECT year, SUM(population) " \
                "FROM PopData " \
                "GROUP BY year; "
        print("Will execute: ", query)
        self.cur.execute(query) #Execute a SQL statement (the query)
        result = self.cur.fetchall() #Fetches all rows from the resultset

        for r in result:
            #print("Considering tuple", r)
            if (r[0] != None and r[1] !=None): 
                year.append(int(r[0]))
                population.append(int(r[1]))

            else:
                print("Dropped tuple ", r) 
        
        #print("Year:", year)
        #print("Population:", population)
        plt.scatter(year, population) #Scatter plot för year (x) och population (y)
        plt.title("Total city population by year in database - Erroneous Data!")
        plt.xlabel("Year interval")
        plt.ylabel("Population data")
        plt.show()# display figure if you run this code locally, otherwise comment out
        return
    
    def regressionplot (self): #2(c)
            # Here we test some concurrency issues.
        city = input("What city do you want to see? ")
        country = input("What country code does " + city + " have? ")
        
        xy = "SELECT year, population " \
                "FROM PopData " \
                "WHERE name LIKE '" + city + "' AND country LIKE '" + country + "' ;"
        
        print("Will execute: ", xy)
        #try:
        self.cur.execute(xy)
        data = self.cur.fetchall()
            #self.conn.commit()
        #except sqlite3.Error as e:
        #    print ("Error message:", e.args[0])
        #    self.conn.rollback()
        #    exit()

        xs= []
        ys= []
        for r in data:
            #print("Considering tuple", r)
            if (r[0]!=None and r[0]!=None):
                xs.append(int(r[0]))
                ys.append(int(r[1]))
            else:
                print("Dropped tuple ", r)
        print("year:", xs)
        print("population:", ys)
        
        
        regline = []

        regr = LinearRegression().fit(np.array(xs).reshape([-1, 1]), np.array(ys).reshape([-1, 1]))
        score = regr.score(np.array(xs).reshape([-1, 1]), np.array(ys).reshape([-1, 1]))
        a = regr.coef_[0][0]
        b = regr.intercept_[0]

        reg_length = xs.copy()
        for i in range(2020,2031):
            reg_length.append(i)

        for i in reg_length:
            regline.append(a * i + b)

        plt.scatter(xs, ys)
        plt.plot(reg_length, regline, color='red')
        plt.title('City population and prediction for: ' +city+' a='+str(a)+', b='+str(b)+', score='+str(score))
        plt.show()
        return

    def linearprediction_allcities (self): #2(d)
        
        self.drop("linearprediction")
        city = []
        query = "CREATE TABLE linearprediction(" \
                "name CHAR(30)," \
                "country CHAR(50)," \
                "a INT," \
                "b INT," \
                "score INT);"
        
        self.cur.execute(query)

        query2 = "SELECT DISTINCT name, country " \
                 "FROM PopData " \
                 "WHERE name IS NOT NULL AND country IS NOT NULL;"
        self.cur.execute(query2)

        r = self.cur.fetchone() #one row

        while r is not None:
            city.append([str(r[0]),str(r[1])])
            r = self.cur.fetchone()
        
        for i in city:
            self.predict_city(i[0],i[1])

        query3 = "SELECT * FROM linearprediction;"
        self.cur.execute(query3)
        data_result = self.cur.fetchall()
        self.print_answer(data_result)

    
    def predict_city(self, city, country):
        query = "SELECT year, population " \
                "FROM PopData " \
                "WHERE name=:city AND country=:country ;"

        self.cur.execute(query, {"city": city, "country": country})
        result = self.cur.fetchall()

        year = []
        population = []

        for r in result:
            if (r[0] != None and r[1] != None):
                year.append(int(r[0]))
                population.append(int(r[1]))
            else:
                print("Dropped tuple ", r)
                
        if len(year)>1:
            
            regr = LinearRegression().fit(np.array(year).reshape([-1, 1]), np.array(population).reshape([-1, 1]))
            score = regr.score(np.array(year).reshape([-1, 1]), np.array(population).reshape([-1, 1]))
            a = regr.coef_[0][0]
            b = regr.intercept_[0]

            if 0<score<1:
                self.cur.execute("INSERT INTO linearprediction(name, country,a,b,score) VALUES (?,?,?,?,?);", 
                (city,country,a,b,score))

    def prediction_q2e (self):
        
        self.drop("prediction")
        query = "CREATE TABLE prediction(" \
                "name CHAR(30)," \
                "country CHAR(50)," \
                "population INT," \
                "year INT);"
        self.cur.execute(query)
        
        query2 = "SELECT * FROM linearprediction;"
        self.cur.execute(query2)
        data_result = self.cur.fetchall()

        for r in data_result:
            for year in range(1950,2051,1):
                name = r[0]
                country = r[1]
                a = r[2]
                b = r[3]

                population = a*year+b
                
                query3 = "INSERT INTO prediction(name,country,population,year) VALUES (?,?,?,?);"
                self.cur.execute(query3, (name,country,population,year))

        query4 = "SELECT * FROM prediction;"
        self.cur.execute(query4)
        data = self.cur.fetchall()
        #self.print_answer(data)

    def prediction_q2f(self):
        query = "SELECT * FROM prediction;"
        self.cur.execute(query)

        result = self.cur.fetchall()
        year = []
        population = []
        
        for r in result:
            # you access ith component of row r with r[i], indexing starts with 0
            # check for null values represented as "None" in python before conversion and drop
            # row whenever NULL occurs
            if (r[3] != None and r[2] !=None): 
                year.append(int(r[3]))
                population.append(int(r[2]))

        
        #print("Year:", year)
        #print("Population:", population)

        query2 = "SELECT AVG(population), MAX(population) " \
                "FROM prediction ;" 
        
        self.cur.execute(query2)
        result2 = self.cur.fetchall()
        
        average = []
        maximum = []
        
        for i in result2: 
            if (i[0] != None and i[1] !=None): 
                average.append(int(i[0]))
                maximum.append(int(i[1]))
        
        print("Average:", average)
        print("Maximum:", maximum)

        plt.scatter(year, population, color = "blue")
        #plt.plot(year, average, color = "red")
        plt.show()
        return
    

    def hypothesis(self):
        #Does economy/Gdp and population correlate? 
        input1 = input("Country correlation with gdp 2020? (A) or City´s yearly growth in agriculture in relation to population (B)?")
        
        query1 = "SELECT * from PopData, Economy " \
                "WHERE Economy.Country = PopData.Country ;"
        
        self.cur.execute(query1)
        result1 = self.cur.fetchall()
        print(result1)

        query2 = "SELECT * " \
                "FROM Economy; " 
        self.cur.execute(query2)
        result2 = self.cur.fetchall()

        gdp = []
        gdp1 = []
        population = []
        unemployment = []

        if input1 == "B":
            for i in result1: 
                if (i[2] != None and i[12] != None): 
                    population.append(int(i[2]))
                    gdp1.append(int(i[12]))

            plt.scatter(gdp, population, color = "green")
            plt.xlabel("GDP")
            plt.ylabel("Population")
            plt.show()

        if input1 == "A":
            for i in result2: 
                if (i[1] != None and i[6] !=None): 
                    gdp.append(int(i[1]))
                    unemployment.append(int(i[6]))
            plt.scatter(gdp, unemployment, color = "blue")
            plt.xlabel("GDP")
            plt.ylabel("Unemployment")
            plt.show()
        return

if __name__ == "__main__":
    db = Program()
    db.run()