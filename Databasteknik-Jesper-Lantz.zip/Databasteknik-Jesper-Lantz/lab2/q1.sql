CREATE VIEW PopData
AS
SELECT 
    Citypops.Year AS year, 
    Citypops.City AS name, 
    Citypops.Population AS population, 
    Citypops.Country AS country,
    City.Longitude as longitude,
    City.Latitude as latitude,
    City.Elevation as elevation,
    Economy.Agriculture as agriculture,
    Economy.Service as service,
    Economy.Industry as industry,
    Economy.Inflation as inflation


FROM
    Citypops, City, Economy

WHERE Citypops.Country = City.Country
AND City.Name = Citypops.City
AND Economy.Country = City.Country;


SELECT * FROM PopData
WHERE name LIKE "Santiago%" LIMIT 5;