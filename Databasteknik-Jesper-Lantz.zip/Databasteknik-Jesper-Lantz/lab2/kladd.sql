CREATE ASSERTION oneShipType CHECK(
    ALL()
    (SELECT COUNT(country)
    FROM Classes
    WHERE type IN ("bb", "bc") 
    GROUP BY country)
);

CREATE ASSERTION checkShip CHECK(
    NOT EXITS 
    (SELECT country
    FROM Classes
    WHERE type = "bb"
    INTERSECT
    (SELECT country
    FROM Classes
    WHERE type = "bc")
));


--q2b)
CREATE ASSERTION noCountryWithBothTypes
CHECK (1 >= ALL
(SELECT COUNT(DISTINCT type) FROM Classes
GROUP BY Country)
);

--IF bb = battleship and bc = battlecruiser then perhaps we could use this one
CREATE ASSERTION CheckCountryType
CHECK ( 1 >= ALL(
    SELECT COUNT(*)
    FROM (
        FROM Classes
        SELECT country, type
        WHERE type == 'bb' or type == 'bc' 
        GROUP BY country, type
        )
    GROUP BY country)
)

CREATE ASSERTION noCountryWithBothTypes
CHECK  (ALL 
(SELECT COUNT(country)
FROM Classes
WHERE type IN('battleship', 'battlecruiser')
GROUP BY Country ) <=1
);


CREATE TRIGGER newDisplacement
AFTER INSERT ON Classes
REFERENCING 
    NEW ROW as NewRow -- NEW ROW AS clause to give a name for the inserted tuple
FOR EACH ROW
BEGIN 
WHEN NewRow.displacement>35000 -- WHEN clause, the action is executed only if the condition following WHEN is true
    UPDATE Classes
    SET displacement=35000
END;

CREATE VIEW StudioPres AS
SELECT name, address, cert#
FROM MovieExec, Studio
WHERE cert#=PresC#;