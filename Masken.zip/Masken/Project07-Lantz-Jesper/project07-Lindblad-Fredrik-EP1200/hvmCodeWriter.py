"""
hvmCodeWriter.py -- Code Writer class for Hack VM translator
"""

import os
from hvmCommands import *
#from Masken.Project_6_VM_I.hvmCommands import *


debug = False

class CodeWriter(object):
    
    def __init__(self, outputName):
        """
        Open 'outputName' and gets ready to write it.
        """
        self.file = open(outputName, 'w')
        self.SetFileName(outputName)

        self.labelNumber = 0
        self.returnLabel = None
        self.callLabel = None
        self.cmpLabels = {}
        self.needHalt = True


    def Debug(self, value):
        """
        Set debug mode.
        Debug mode writes useful comments in the output stream.
        """
        global debug
        debug = value


    def Close(self):
        """
        Write a jmp $ and close the output file.
        """
        if self.needHalt:
            if debug:
                self.file.write('    // <halt>\n')
            label = self._UniqueLabel()
            self._WriteCode('@%s, (%s), 0;JMP' % (label, label))
        self.file.close()


    def SetFileName(self, fileName):
        """
        Sets the current file name to 'fileName'.
        Restarts the local label counter.

        Strips the path and extension.  The resulting name must be a
        legal Hack Assembler identifier.
        """
        if (debug):
            self.file.write('    // File: %s\n' % (fileName))
        self.fileName = os.path.basename(fileName)
        self.fileName = os.path.splitext(self.fileName)[0]
        self.functionName = None


    def Write(self, line):
        """
        Raw write for debug comments.
        """
        self.file.write(line + '\n')

    def _UniqueLabel(self):
        """
        Make a globally unique label.
        The label will be _sn where sn is an incrementing number.
        """
        self.labelNumber += 1
        return '_' + str(self.labelNumber)


    def _LocalLabel(self, name):
        """
        Make a function/module unique name for the label.
        If no function has been entered, the name will be
        FileName$$name. Otherwise it will be FunctionName$name.
        """
        if self.functionName != None:
            return self.functionName + '$' + name
        else:
            return self.fileName + '$$' + name


    def _StaticLabel(self, index):
        """
        Make a name for static variable 'index'.
        The name will be FileName.index
        """
        return self.fileName + '.' + str(index)    


    def _WriteCode(self, code):
        """
        Write the comma separated commands in 'code'.
        """
        code = code.replace(',', '\n').replace(' ', '')
        self.file.write(code + '\n')
        

 
        

    """"
    The functions to be implemented are found beyond this point 
    """
	
    """
    Parameters: 

    Result: 
    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
    For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
    Returns: 
    Nothing.
    Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
    Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
    Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.
    """


    def WritePushPop(self, commandType, segment, index):
        #print(commandType)
        #print(C_PUSH)
        segments_D = {'local': 'LCL', 'argument': 'ARG', 'this': 'THIS', 'that': 'THAT', 'pointer': '3',
                      'temp': '5'}  # temp från 5 och pointer är THIS och THAT
        if commandType== C_PUSH:
            stackCode='@SP,A=M,M=D,@SP,M=M+1,' #förekommer flera gånger för PUSH commandon.
            #print(commandType)
            if segment in (T_THIS, T_THAT, T_ARGUMENT,T_LOCAL):

                line='@'+str(index)+',D=A,@'+segments_D.get(segment)+',A=M+D,D=M,'+stackCode #assembly kod för segmenten är liknande, använder således Dict.


            if segment==T_CONSTANT: #Om T_CONSTANT
                #print(segment)
                line='@'+str(index)+',D=A,'+stackCode #Pushar konstant, adderar SP++ för ny pekare på nästa minne

            if segment in (T_POINTER,T_TEMP): #OM i Pointer eller Temp. Hämtar ut värde mha Dict
                line='@'+str(index)+',D=A,@'+segments_D.get(segment)+',A=D+A,D=M,'+stackCode

            if segment in T_STATIC: #STATIC ska vara global filnamn.index
                #print(segment)
                line='@'+self.fileName+'.'+str(index)+',D=M,'+stackCode


        elif commandType==C_POP: #Om POP, alla arguments har inte POP.

            stackCode2='@SP,M=M-1,A=M,D=M,'
            tempRegister=',D=A+D,@R13,M=D,@SP,M=M-1,A=M,D=M,@R13,A=M,M=D' #temporärt för att lagra värden för att poppa enkelt
            if segment== T_STATIC: #SAmma som i PUSH förutom att vi PUSHAR
                print(segment)
                line =stackCode2+'@'+self.fileName+'.'+str(index)+',M=D,'

            elif segment in (T_THIS, T_THAT, T_ARGUMENT,T_LOCAL): #Som ovan
                line='@'+str(index)+',D=A,@'+segments_D.get(segment)+',A=M,'+tempRegister

            elif segment in(T_POINTER,T_TEMP): #SOm ovan
                line='@'+str(index)+',D=A,@'+segments_D.get(segment)+tempRegister

        self._WriteCode(line)
        #return line
        """
        Write Hack code for 'commandType' (C_PUSH or C_POP).
        'segment' (string) is the segment name.
        'index' (int) is the offset in the segment.
	To be implemented as part of Project 6
	
	    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
        For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
        Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
        Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
        Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.

        """
        
    def WriteArithmetic(self, command):
        """
        Write Hack code for stack arithmetic 'command' (str).
	To be implemented as part of Project 6
	    
		Compiles the arithmetic VM command into the corresponding ASM code. Recall that the operands (one or two, depending on the command) are on the stack and the result of the operation should be placed on the stack.
        The unary and the logical and arithmetic binary operators are simple to compile. 
         The three comparison operators (EQ, LT and GT) do not exist in the assembly language. The corresponding assembly commands are the conditional jumps JEQ, JLT and JGT. You need to implement the VM operations using these conditional jumps. You need two labels, one for the true condition and one for the false condition and you have to put the correct result on the stack.
        """
        command_D = {'add': '+', 'sub': '-', 'neg': '-', 'not': '!', 'and': '&', 'or': '|', 'eq': 'JEQ', 'lt': 'JLT',
                     'gt': 'JGT'}
        push='@SP,A=M,M=D,@SP,M=M+1'
        pop='@SP,M=M-1,A=M,D=M,'
        if command in (T_NEG,T_NOT): #Plockar ut värdet som SP pekar på, Väljer vad command ska göra och skickar tillbakla till SP
            line='@SP,M=M-1,A=M,M='+command_D.get(command)+'M,@SP,M=M+1,'
        elif command in (T_ADD,T_SUB,T_AND,T_OR): #Behöver de två första att POPas från stacken
            #print(command)
            line=pop+'@SP,M=M-1,A=M,M=M'+command_D.get(command)+'D,@SP,M=M+1,' #Poppar två första från stacken, utför commandet och lagrar tillbaka till SP

        # elif command in (T_EQ,T_LT,T_GT): #
        #     print(command)
        #     line=pop+'@SP,M=M-1,A=M,M=D'+command_D.get(T_SUB)+'M,@SP,M=M+1,'
        #     line+=pop+'D;'+command_D.get(command)+',@SP,M=M+1,' #jämför med argumentet som returnrar false eller true och lägger tillbaka i stacken

        elif command in (T_LT,T_EQ,T_GT):
            self.labelNumber+=1
            nr=str(self.labelNumber)
            if command == T_EQ:
                line = pop + '@SP,M=M-1,A=M,D=M' + command_D.get(T_SUB) + 'D,@TRUE'+nr+',D;JEQ,@SP,A=M,M=0,@FALSE'+nr+',0;JEQ,(TRUE'+nr+'),@SP,A=M,M=-1,(FALSE'+nr+'),@SP,M=M+1'
            if command == T_GT:
                line = pop + '@SP,M=M-1,A=M,D=M' + command_D.get(T_SUB) + 'D,@TRUE'+nr+',D;JGT,@SP,A=M,M=0,@FALSE'+nr+',0;JEQ,(TRUE'+nr+'),@SP,A=M,M=-1,(FALSE'+nr+'),@SP,M=M+1'
            if command == T_LT:
                line = pop + '@SP,M=M-1,A=M,D=M' + command_D.get(T_SUB) + 'D,@TRUE'+nr+',D;JLT,@SP,A=M,M=0,@FALSE'+nr+',0;JEQ,(TRUE'+nr+'),@SP,A=M,M=-1,(FALSE'+nr+'),@SP,M=M+1'

        self._WriteCode(line)
        #return line
    def WriteInit(self, sysinit = True):
        """
        Write the VM initialization code:
	To be implemented as part of Project 7
        """
        if (debug):
            self.file.write('    // Initialization code\n')
        if sysinit:
            self._WriteCode("@256, D=A, @SP, M=D,")  #mappar till ram 256
            self.WriteCall("Sys.init", 0)

    def WriteLabel(self, label):
        """
        Write Hack code for 'label' VM command.
	To be implemented as part of Project 7 """
        self._WriteCode('('+label+')')


    def WriteGoto(self, label):
        """
        Write Hack code for 'goto' VM command.
	To be implemented as part of Project 7
        """
        self._WriteCode('@'+label+',0;JMP,')

    def WriteIf(self, label):
        print(label)
        """
        Write Hack code for 'if-goto' VM command.
	To be implemented as part of Project 7
        """
        pop = '@SP,AM=M-1,D=M,' #poppar
        line=pop+'@'+label+',D;JNE,' #kollar om D är skiljt från 0
        self._WriteCode(line)

    def WriteFunction(self, functionName, numLocals):
        """
        Write Hack code for 'function' VM command.
	To be implemented as part of Project 7
        """
        push = ',@SP,A=M,M=0,@SP,M=M+1,' #pusha nollor till stacken
        self.WriteLabel(functionName) #skapar label

        for i in range(int(numLocals)): #skapar utrymme på stacken (nollor), antal lika många som numLocals
            line=push
            self._WriteCode(line)

    def WriteReturn(self):
        """
        Write Hack code for 'return' VM command.
	To be implemented as part of Project 7
        """
        line='@LCL,D=M,@R14,M=D,@5,D=A,@R14,D=M-D,A=D,D=M,@R15,M=D,'#temp variable lagras i R14 + return address i temporär variable R15 +Framw -5
        line+='@0,D=A,@ARG,A=M,D=A+D,@R13,M=D,@SP,M=M-1,A=M,D=M,@R13,A=M,M=D,'# *ARG=POP(), repositionerar returvärdet för callern
        line+='@ARG,D=M,@SP,M=D+1,'#*ARG=pop,SP=ARG+1
        line+='@R14,M=M-1,A=M,D=M,@THAT,M=D,' #restore THAT för caller
        line+='@R14,M=M-1,A=M,D=M,@THIS,M=D,'#restore THIS för caller
        line += '@R14,M=M-1,A=M,D=M,@ARG,M=D,'#restore ARG för caller
        line += '@R14,M=M-1,A=M,D=M,@LCL,M=D,' #restore LCL för caller
        line+= '@R15,A=M,0;JMP,' #goto return address. R15=Returnadress, GOTO ret
        self._WriteCode(line)



    def WriteCall(self, functionName, numArgs):
        """
        Write Hack code for 'call' VM command.
	To be implemented as part of Project 7
        """

        self.labelNumber+=1
        moveSP='@SP,A=M,M=D,@SP,M=M+1,'
        line='@RETURN'+str(self.labelNumber)+',D=A,'+moveSP #push returnadress
        line+='@LCL,D=M,'+moveSP #sparar LCL för "caller"
        line+='@ARG,D=M,'+moveSP #sparar ARG för "caller"
        line+='@THIS,D=M,'+moveSP #sparar THIS för "caller"
        line+='@THAT,D=M,'+moveSP #sparar THAT för "caller"

        #line+='@SP,D=M,@'+str(int(numArgs)+int(5))+',D=D-A,@ARG,M=D,@SP,D=M,@LCL,M=D,'
        line+='@5,D=A,@SP,D=M-D,@'+str(int(numArgs))+',D=D-A,@ARG,M=D,' #Flyttar ARG
        line+='@SP,D=M,@LCL,M=D,@'+str(functionName)+',0;JMP,' #LCL=SP
        self._WriteCode(line)
        self.WriteGoto(functionName)
        self.WriteLabel('RETURN'+str(self.labelNumber))

