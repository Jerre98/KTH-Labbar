"""
hvmCodeWriter.py -- Code Writer class for Hack VM translator
"""

import os
from hvmCommands import *

debug = False
# CodeWriter translates VM commands into Hack assembly code

class CodeWriter(object):
    
    def __init__(self, outputName):
        """
        Open 'outputName' and gets ready to write it.
        """
        self.file = open(outputName, 'w')
        self.SetFileName(outputName)

        self.labelNumber = 0
        self.returnLabel = None
        self.callLabel = None
        self.cmpLabels = {}
        self.needHalt = True


    def Debug(self, value):
        """
        Set debug mode.
        Debug mode writes useful comments in the output stream.
        """
        global debug
        debug = value


    def Close(self):
        """
        Write a jmp $ and close the output file.
        """
        if self.needHalt:
            if debug:
                self.file.write('    // <halt>\n')
            label = self._UniqueLabel()
            self._WriteCode('@%s, (%s), 0;JMP' % (label, label))
        self.file.close()


    def SetFileName(self, fileName):
        """
        Sets the current file name to 'fileName'.
        Restarts the local label counter.

        Strips the path and extension.  The resulting name must be a
        legal Hack Assembler identifier.
        """
        if (debug):
            self.file.write('    // File: %s\n' % (fileName))
        self.fileName = os.path.basename(fileName)
        self.fileName = os.path.splitext(self.fileName)[0]
        self.functionName = None


    def Write(self, line):
        """
        Raw write for debug comments.
        """
        self.file.write(line + '\n')

    def _UniqueLabel(self):
        """
        Make a globally unique label.
        The label will be _sn where sn is an incrementing number.
        """
        self.labelNumber += 1
        return '_' + str(self.labelNumber)


    def _LocalLabel(self, name):
        """
        Make a function/module unique name for the label.
        If no function has been entered, the name will be
        FileName$$name. Otherwise it will be FunctionName$name.
        """
        if self.functionName != None:
            return self.functionName + '$' + name
        else:
            return self.fileName + '$$' + name


    def _StaticLabel(self, index):
        """
        Make a name for static variable 'index'.
        The name will be FileName.index
        """
        return self.fileName + '.' + str(index)    


    def _WriteCode(self, code):
        """
        Write the comma separated commands in 'code'.
        """
        code = code.replace(',', '\n').replace(' ', '')
        self.file.write(code + '\n')
        

 
        

    """"
    The functions to be implemented are found beyond this point 
    """
	
    """
    Parameters: 

    Result: 
    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
    For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
    Returns: 
    Nothing.
    Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
    Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
    Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.
    """


    def WritePushPop(self, commandType, segment, index):
        """
        Write Hack code for 'commandType' (C_PUSH or C_POP).
        'segment' (string) is the segment name.
        'index' (int) is the offset in the segment.
	To be implemented as part of Project 6
	
	    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
        For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
        Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
        Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
        Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.

        """
######VM Mapping on the Hack platform#######
#RAM addresses: Usage
#0–15: 16 virtual registers, whose usage is described below
#16–255: Static variables (of all the VM functions in the VM program)
#256–2047: Stack 

#Memory access commands transfer data between the stack and virtual memory segments.

#Register Name - Usage
#RAM[0] SP Stack pointer: points to the next topmost location in the stack
#RAM[1] LCL Points to the base of the current VM function's local segment
#RAM[2] ARG Points to the base of the current VM function 's argument segment
#RAM[3] THIS Points to the base of the current this segment (within the heap)
#RAM[4] THAT Points to the base of the current that segment (within the heap)
#RAM[5-12] TEMP Hold the contents of the temp segment
#RAM[13-15] (-) Can be used by the VM implementation as general-purpose registers. 

##Push constant 2:
#@2   Vi får värdet 2 // D = value
#D=A 
        if commandType==C_PUSH: # '2'
        
## @SP // sätt det där SP pekar, place value on stack
#A=M
#M=D
#@SP //Öka med 1, increment stack pointer
#M = M+1 
            push =  "@SP, A=M, M=D, @SP, M=M+1" #Lägga till
        
#@LCL adress i faktiska minnet
#A=D+M
#D=M få värdet vid adress A   och kastar in i stacken   
            if segment in T_LOCAL:
                kombination = "@" + str(index) + ", D=A, @LCL,A=D+M,D=M, " + push 

            elif segment in T_ARGUMENT:
                kombination = "@" + str(index)+ ",D=A,@ARG,A=D+M,D=M, " + push

            elif segment in T_THIS:
                kombination = "@" + str(index)+ ",D=A,@THIS,A=D+M,D=M, " + push

            elif segment in T_THAT:
                kombination = "@" + str(index)+ ",D=A,@THAT,A=D+M,D=M, " + push
            
            elif segment in T_POINTER: 
                kombination="@"+str(index)+ ",D=A,@3,A=D+A,D=M, " + push#@3 (base address for pointer)

            elif segment in T_TEMP: 
                kombination="@"+str(index)+ ",D=A,@5,A=D+A,D=M, " + push#@5 (base address for temp)

            elif segment in T_CONSTANT:
                kombination="@"+str(index)+",D=A, " + push

            elif segment in T_STATIC:
                kombination="@"+ self._StaticLabel(index) + ",D=M, " + push
        
    #Pop
        elif commandType == C_POP:

            pop = ",@R13,M=D,@SP,M=M-1,A=M,D=M,@R13,A=M,M=D," #utnyttja RAM[13]

            if segment in T_THIS:
                kombination = "@" +str(index)+",D=A,@THIS,A=M,D=D+A"+pop
            elif segment in T_THAT:
                kombination = "@" +str(index)+",D=A,@THAT,A=M,D=D+A"+pop
            elif segment in T_LOCAL:
                kombination = "@" +str(index)+",D=A,@LCL,A=M,D=D+A"+pop
            elif segment in  T_ARGUMENT:
                kombination = "@" +str(index)+",D=A,@ARG,A=M,D=D+A"+pop

            elif segment in T_POINTER:
                kombination = "@"+str(index)+",D=A,@3,D=A+D"+ pop #@3 (base address for pointer)

            elif segment in T_TEMP:
                kombination = "@"+str(index)+",D=A,@5,D=A+D"+ pop #@5 (base address for temp)

            elif segment == T_STATIC:
                kombination="@SP,M=M-1,A=M,D=M," + "@"+self._StaticLabel(index)+",M=D,"

        self._WriteCode (kombination)

    def WriteArithmetic(self, command):
        """
        Write Hack code for stack arithmetic 'command' (str).
	To be implemented as part of Project 6
	    
		Compiles the arithmetic VM command into the corresponding ASM code. Recall that the operands (one or two, depending on the command) are on the stack and the result of the operation should be placed on the stack.
        The unary and the logical and arithmetic binary operators are simple to compile. 
         The three comparison operators (EQ, LT and GT) do not exist in the assembly language. The corresponding assembly commands are the conditional jumps JEQ, JLT and JGT. You need to implement the VM operations using these conditional jumps. You need two labels, one for the true condition and one for the false condition and you have to put the correct result on the stack.
        """
        command_dict = {'add': '+', 'sub': '-', 'neg': '-', 'not': '!', 'and': '&', 'or': '|', 'eq': 'JEQ', 'lt': 'JLT',
                     'gt': 'JGT'}
        pop="@SP,M=M-1,A=M,D=M," #//minska med 1, decrement stack pointer, place value on stack, #D=M få värdet vid adress A och kastar in i stacken  

        if command in (T_NEG, T_NOT): #Ta ut värdet som SP pekar på, choose what command is supposed to do and send back to SP 
            kombination = '@SP,M=M-1,A=M,M='+command_dict.get(command)+'M,@SP,M=M+1,'
        elif command in (T_ADD, T_SUB, T_AND, T_OR): #Need first two to POP from stack
            kombination = pop + '@SP,M=M-1,A=M,M=M'+command_dict.get(command)+'D,@SP,M=M+1,' # Pop two first from stack and perform command and store back to SP 

        elif command in (T_LT,T_EQ,T_GT):
            if command == T_EQ:
                kombination = pop + '@SP,M=M-1,A=M,D=M' + command_dict.get(T_SUB) + 'D,@TRUE,D;JEQ,@SP,A=M,M=0,@FALSE,0;JEQ,(TRUE),@SP,A=M,M=-1,(FALSE)'
            if command == T_GT:
                kombination = pop + '@SP,M=M-1,A=M,D=M' + command_dict.get(T_SUB) + 'D,@TRUE,D;JGT,@SP,A=M,M=0,@FALSE,0;JEQ,(TRUE),@SP,A=M,M=-1,(FALSE)'
            if command == T_LT:
                kombination = pop + '@SP,M=M-1,A=M,D=M' + command_dict.get(T_SUB) + 'D,@TRUE,D;JLT,@SP,A=M,M=0,@FALSE,0;JEQ,(TRUE),@SP,A=M,M=-1,(FALSE)'

        self._WriteCode(kombination)
        
    def WriteInit(self, sysinit = True):
        """
        Write the VM initialization code:
	To be implemented as part of Project 7
        """
        if (debug):
            self.file.write('    // Initialization code\n')


    def WriteLabel(self, label):
        """
        Write Hack code for 'label' VM command.
	To be implemented as part of Project 7

        """

    def WriteGoto(self, label):
        """
        Write Hack code for 'goto' VM command.
	To be implemented as part of Project 7
        """

    def WriteIf(self, label):
        """
        Write Hack code for 'if-goto' VM command.
	To be implemented as part of Project 7
        """
        

    def WriteFunction(self, functionName, numLocals):
        """
        Write Hack code for 'function' VM command.
	To be implemented as part of Project 7
        """


    def WriteReturn(self):
        """
        Write Hack code for 'return' VM command.
	To be implemented as part of Project 7
        """

    def WriteCall(self, functionName, numArgs):
        """
        Write Hack code for 'call' VM command.
	To be implemented as part of Project 7
        """

    
