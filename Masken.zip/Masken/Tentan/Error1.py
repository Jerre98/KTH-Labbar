"""
hjcError.py -- Error exceptions for Hack Jack compiler
"""

class HjcError(Exception):
    pass
    
