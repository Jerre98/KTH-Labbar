"""
hvmCodeWriter.py -- Code Writer class for Hack VM translator
"""

import os
from hvmCommands import *

debug = False
# CodeWriter translates VM commands into Hack assembly code

class CodeWriter(object):
    
    def __init__(self, outputName):
        """
        Open 'outputName' and gets ready to write it.
        """
        self.file = open(outputName, 'w')
        self.SetFileName(outputName)

        self.labelNumber = 0
        self.returnLabel = None
        self.callLabel = None
        self.cmpLabels = {}
        self.needHalt = True


    def Debug(self, value):
        """
        Set debug mode.
        Debug mode writes useful comments in the output stream.
        """
        global debug
        debug = value


    def Close(self):
        """
        Write a jmp $ and close the output file.
        """
        if self.needHalt:
            if debug:
                self.file.write('    // <halt>\n')
            label = self._UniqueLabel()
            self._WriteCode('@%s, (%s), 0;JMP' % (label, label))
        self.file.close()


    def SetFileName(self, fileName):
        """
        Sets the current file name to 'fileName'.
        Restarts the local label counter.

        Strips the path and extension.  The resulting name must be a
        legal Hack Assembler identifier.
        """
        if (debug):
            self.file.write('    // File: %s\n' % (fileName))
        self.fileName = os.path.basename(fileName)
        self.fileName = os.path.splitext(self.fileName)[0]
        self.functionName = None


    def Write(self, line):
        """
        Raw write for debug comments.
        """
        self.file.write(line + '\n')

    def _UniqueLabel(self):
        """
        Make a globally unique label.
        The label will be _sn where sn is an incrementing number.
        """
        self.labelNumber += 1
        return '_' + str(self.labelNumber)


    def _LocalLabel(self, name):
        """
        Make a function/module unique name for the label.
        If no function has been entered, the name will be
        FileName$$name. Otherwise it will be FunctionName$name.
        """
        if self.functionName != None:
            return self.functionName + '$' + name
        else:
            return self.fileName + '$$' + name


    def _StaticLabel(self, index):
        """
        Make a name for static variable 'index'.
        The name will be FileName.index
        """
        return self.fileName + '.' + str(index)    


    def _WriteCode(self, code):
        """
        Write the comma separated commands in 'code'.
        """
        code = code.replace(',', '\n').replace(' ', '')
        self.file.write(code + '\n')
        

 
        

    """"
    The functions to be implemented are found beyond this point 
    """
	
    """
    Parameters: 

    Result: 
    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
    For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
    Returns: 
    Nothing.
    Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
    Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
    Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.
    """


    def WritePushPop(self, commandType, segment, index):
        """
        Write Hack code for 'commandType' (C_PUSH or C_POP).
        'segment' (string) is the segment name.
        'index' (int) is the offset in the segment.
	To be implemented as part of Project 6
	
	    For push: Pushes the content of segment[index] onto the stack. It is a good idea to move the value to be pushed into a register first, then push the content of the register to the stack.
        For pop: Pops the top of the stack into segment[index]. You may need to use a general purpose register (R13-R15) to store some temporary results.
        Hint: Recall that there are 8 memory segments in the VM model, but only 5 of these exist in the assembly definition. Also, not all 8 VM segments allow to perform both pop and push on them. Chapter 7.3 of the book explains memory segment mapping.
        Hint: Use pen and paper first. Figure out how to compute the address of segment[index] (except for constant). Then figure out how you move the value of segment[index] into a register (by preference D). Then figure out how to push a value from a register onto the stack. 
        Hint: For pop, you already know how to compute the address of segment[index]. Store it in a temporary register (you can use R13 to R15 freely). Then read the value from the top of the stack, adjust the top of the stack, and then store the value at the location stored in the temporary register.

        """
######VM Mapping on the Hack platform#######
#RAM addresses: Usage
#0–15: 16 virtual registers, whose usage is described below
#16–255: Static variables (of all the VM functions in the VM program)
#256–2047: Stack 

#Memory access commands transfer data between the stack and virtual memory segments.

#Register Name - Usage
#RAM[0] SP Stack pointer: points to the next topmost location in the stack
#RAM[1] LCL Points to the base of the current VM function's local segment
#RAM[2] ARG Points to the base of the current VM function 's argument segment
#RAM[3] THIS Points to the base of the current this segment (within the heap)
#RAM[4] THAT Points to the base of the current that segment (within the heap)
#RAM[5-12] TEMP Hold the contents of the temp segment
#RAM[13-15] (-) Can be used by the VM implementation as general-purpose registers. 

        code_dict = {
                'local'     : "@LCL, D=M, @" + str(index) + ", D=D+A, A=D, D=M,",   # D = RAM[base+i]
                'argument'  : "@ARG, D=M, @" + str(index) + ", D=D+A, A=D, D=M,",
                'this'      : "@THIS, D=M, @" + str(index) + ", D=D+A, A=D, D=M,",
                'that'      : "@THAT, D=M, @" + str(index) + ", D=D+A, A=D, D=M,",
                'pointer'   : "@3, D=A, @" + str(index) + ", D=D+A, A=D, D=M,",     # D = RAM[3+i].
                'temp'      : "@5, D=A, @" + str(index) + ", D=D+A, A=D, D=M,",     # D = RAM[5+i].
                'constant'  : "@" + str(index) + ", D=A,",                          # D = i.
                'static'    : "@" + self.fileName + "." + str(index) + ", D=M,"     # D = RAM[filename.i]
            }

        if commandType == C_PUSH:
            code = "@SP, A=M, M=D, @SP, M=M+1" # Code to push into stack.
        else:
            code = "D=A, @13, M=D, @SP, M=M-1, A=M, D=M, @13, A=M, M=D" # Code to pop from stack to address.

        self._WriteCode(code_dict[segment] + code)

    def WriteArithmetic(self, command):
        """
        Write Hack code for stack arithmetic 'command' (str).
	To be implemented as part of Project 6
	    
		Compiles the arithmetic VM command into the corresponding ASM code. Recall that the operands (one or two, depending on the command) are on the stack and the result of the operation should be placed on the stack.
        The unary and the logical and arithmetic binary operators are simple to compile. 
         The three comparison operators (EQ, LT and GT) do not exist in the assembly language. The corresponding assembly commands are the conditional jumps JEQ, JLT and JGT. You need to implement the VM operations using these conditional jumps. You need two labels, one for the true condition and one for the false condition and you have to put the correct result on the stack.
        """
        arithmetic = {
            'add'   : "M=M+D",     # x = x + y.
            'sub'   : "M=M-D"      # x = x - y.
        }
        comparison = {  
            'eq'    : "D;JEQ,",
            'lt'    : "D;JLT,",
            'gt'    : "D;JGT,"  
        }
        logical = {
            'and'   : "M=D&M",  # M = D and M.
            'or'    : "M=D|M"   # M = D or M.
        }
        if command in arithmetic:
            self._WriteCode(
                "@SP, M=M-1, A=M, D=M, A=A-1,"   # D = 1st value on stack, A = address to 2nd value.
                + arithmetic[command]
            )
        elif command in logical:
            self._WriteCode(
                "@SP, M=M-1, A=M, D=M, A=A-1," + logical[command])
        elif command == 'neg':
            self._WriteCode("@SP, A=M-1, M=-M")     # y = -y.
        elif command == 'not':
            self._WriteCode("@SP, A=M-1, M=!M")	
        elif command in comparison:
            false_label = self._UniqueLabel()   # To avoid conflicting labels.
            true_label = self._UniqueLabel()
            self._WriteCode(
                "@SP, M=M-1, A=M, D=M, @13, M=D,"   
                "@SP, A=M-1, D=M, @13, D=D-M,"           # D = 2nd stack value - 1st stack value.
                "@" + true_label + ", " + comparison[command] + 
                "@SP, A=M-1, M=0, @" + false_label + ","
                "0;JMP, (" + true_label + "),"        # Jump to FALSE after stack top is set to -1.
                "@SP, A=M-1, M=-1, (" + false_label + ")"
            ) 
        
        
    def WriteInit(self, sysinit = True):
        """
        Write the VM initialization code:
	To be implemented as part of Project 7
        """
        
        if (debug):
            self.file.write('    // Initialization code\n')
        
        if sysinit:
            kombination= "@256, D=A, @SP, M=D" #SP=256
            self._WriteCode(kombination) #Map to RAM256
            self.WriteCall("Sys.init", 0) #start executing the translated code of Sys.init
###Branching commands###

#This command labels the current location in the function’s code.
    def WriteLabel(self, label):
        """
        Write Hack code for 'label' VM command.
	To be implemented as part of Project 7

        """
        self._WriteCode('('+label+')')

#This command effects an unconditional goto operation, causing execution to continue from the location marked by the label. 
#The jump destination must be located in the same function.
    def WriteGoto(self, label):
        """
        Write Hack code for 'goto' VM command.
	To be implemented as part of Project 7
        """
        self._WriteCode('@'+label+',0;JMP,')

#This command effects a conditional goto operation. 
#The stack’s topmost value is popped; if the value is not zero, 
# execution continues from the location marked by the label; otherwise, 
# execution continues from the next command in the program. 
# The jump destination must be located in the same function.
    ###Translate ifgoto###
    def WriteIf(self, label):
        """
        Write Hack code for 'if-goto' VM command.
	To be implemented as part of Project 7
        """
#jump if top most item on stack is not equal to zero
        print(label)
        pop = '@SP,AM=M-1,D=M,' #Pop top most value item off stack
        kombination = pop+'@'+label+',D;JNE,' #Examine if D is not 0
        self._WriteCode(kombination)
        

    def WriteFunction(self, functionName, numLocals):
        """
        Write Hack code for 'function' VM command.
	To be implemented as part of Project 7
        """
        
        self.WriteLabel(functionName) #create label
#push zeros to the stack
        for i in range(int(numLocals)): #create space on the stack:zeros, antalet är lika många som numLocals. #Dvs hur många lokala variabeler det är i den funktionen
            self.WritePushPop(C_PUSH, T_CONSTANT, "0")

    def WriteReturn(self):
        """
        Write Hack code for 'return' VM command.
	To be implemented as part of Project 7
        """
        kombination='@LCL,D=M,@R14,M=D,@5,D=A,@R14,D=M-D,A=D,D=M,@R15,M=D,'
        kombination+='@0,D=A,@ARG,A=M,D=A+D,@R13,M=D,@SP,M=M-1,A=M,D=M,@R13,A=M,M=D,'# *ARG=POP(), reposition return value for caller
        kombination+='@ARG,D=M,@SP,M=D+1,'#*ARG=pop,SP=ARG+1
        kombination+='@R14,M=M-1,A=M,D=M,@THAT,M=D,' #restore THAT 
        kombination+='@R14,M=M-1,A=M,D=M,@THIS,M=D,'#restore THIS 
        kombination += '@R14,M=M-1,A=M,D=M,@ARG,M=D,'#restore ARG 
        kombination += '@R14,M=M-1,A=M,D=M,@LCL,M=D,' #restore LCL 
        kombination+= '@R15,A=M,0;JMP,' #goto return address. R15=Returnadress, goto return
        self._WriteCode(kombination)



    def WriteCall(self, functionName, numArgs):
        """
        Write Hack code for 'call' VM command.
	To be implemented as part of Project 7
        """

        self.labelNumber+=1
        flyttaSP='@SP,A=M,M=D,@SP,M=M+1,'
        kombination='@RETURN'+str(self.labelNumber)+',D=A,'+ flyttaSP #push the return address
        kombination+='@LCL,D=M,'+ flyttaSP #ssave LCL for "caller"
        kombination+='@ARG,D=M,'+ flyttaSP #save ARG for "caller"
        kombination+='@THIS,D=M,'+ flyttaSP #save THIS for "caller"
        kombination+='@THAT,D=M,'+ flyttaSP #save THAT for "caller"

        #line+='@SP,D=M,@'+str(int(numArgs)+int(5))+',D=D-A,@ARG,M=D,@SP,D=M,@LCL,M=D,'
        kombination+='@5,D=A,@SP,D=M-D,@'+str(int(numArgs))+',D=D-A,@ARG,M=D,' #Flyttar ARG
        kombination+='@SP,D=M,@LCL,M=D,@'+str(functionName)+',0;JMP,' #LCL=SP
        self._WriteCode(kombination)
        self.WriteGoto(functionName)
        self.WriteLabel('RETURN'+str(self.labelNumber))
