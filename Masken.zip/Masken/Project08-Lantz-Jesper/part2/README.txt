JackAnalyzerT.py only calls the tokenizer and generates the *T.xml files.
JackAnalyzer.py is the final version of the Jack syntax analyzer.
