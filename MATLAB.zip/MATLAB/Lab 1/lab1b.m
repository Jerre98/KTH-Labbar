function Lab_1(chooseProgram)

%Initial values
    M = 10;
    t_min = 0;
    t_max = 40;
    g = 5;
    h = 0.1;
    N = (t_max-t_min)/h; % antal steg
    t_n = t_min:h:t_max; %Alla tidssteg
    carDistanceBrake = [75:75:75*M]; % Bilarnas avstånd vid t_min
    carDistanceAcc = [10:10:10*M];
    error = 10^(-5);
    
    if chooseProgram == 1
        carPlotter(d_max, v_max, h, carDistanceBrake, M, t_n, g)
    elseif chooseProgram == 2
        carPlotter (d_max, v_max, h, carDistanceAcc, M, t_n, v_max)
        
    end
end
%All time steps with F.E
function carPlotter(d_max, v_max,h,X, M, t_n, g)
    hold on;
    for n = t_n %n är iterationstalet
        plot(n, X, ".")
        X = ForwEulerStep(X, h,d_max, v_max, g, M); %Kallar på funktion step 
    end
end
function nextX = ForwEulerStep(X, h, d_max, v_max,g, M)
    nextX = zeros(1,M);
    for i = M:-1:1
        if i == M
            nextX(i) = X(i)+ h*g;
        else
            nextX(i) = X(i) + h*velocity(X(i+1)-X(i));
        end
    end
end
    
%del c)
function carPartC(d_max, v_max, t_max, h, M)
    x = zeros(N, M);
    for i = 1:1:N
        x(i,:) = X;
        X = ForwEulerStep(X, h, d_max, v_max, M);
    end
    
    for n=1:N    
    plot(x(:, n),zeros(1,M),'r*');
    axis([0 1000 -1 1])
    drawnow
    pause(h)
    end
end



%Label
xlabel('t')
ylabel('Y_0')


%Uppgift g)
for n = 1:N-1
    X(M,n+1) = X(M,n)+h*g; %DE (3) för M
    for k = M-1:-1:1
        y0 = 0;
        x0 = 0;
        j = 0;
        while y0 ~= X(k,n) + h*velocity(X(k+1,n+1)-x0) && j<5
            y0 = X(k,n) + h*velocity(X(k+1,n+1)-x0);
            x0 = y0;
            j = j+1;
        end
        X(k,n+1) = y0;
    end
end
disp(X)
        
      
%One step with F.E
function Y_next = step(Y_now, h, g, M);
    Y_next = zeros(1, M); 
    Y_next(M) = Y_now(M)+h*g;
    for i = M-1:-1:1
        Y_next(i)=Y_now(i)+h*velocity(Y_now(i+1)-Y_now(i));
    end
end

%Implicit Euler Method, pos=x
function Y_last = implicitEuler(g, h, M, t_max, N, Y_0);
   pos_matrix = zeros(M,N);
   pos_matrix(:,1) = Y_0;
   for n = 1:N-1
       pos_matrix(M,n+1) = pos_matrix(M,n)+h*g;
       for i = (M-1):-1:1
           pos_matrix(i, n+1) = (h*pos_matrix(i+1, n+1)+ 3*pos_matrix(i,n))/(h+3);
           if ((pos_matrix(i+1,n+1)-pos_matrix(i, n+1)) >=75)
               pos_matrix(i,n+1) = pos_matrix(i,n)+25*h;
           end
       end
end
    










