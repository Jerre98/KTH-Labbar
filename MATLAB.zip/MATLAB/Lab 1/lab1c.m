
M = 10;
t_min = 0;
t_max = 40;
h = 0.1;
N = (t_max-t_min)/h; % antal steg


A = zeros(N, M)
for n=1:N
plot(A(n,:),zeros(M, 1),'r*');
axis([0 200 -1 1])
drawnow
pause(h)
end