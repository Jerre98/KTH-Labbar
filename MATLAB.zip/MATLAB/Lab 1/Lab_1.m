function Lab_1(chooseProgram)

%Initial values
    M = 14;
    d_max = 75;
    v_max = 25;
    t_min = 0;
    t_max = 40;
    g = 5;
    h = 0.1;
    N = (t_max-t_min)/h; % antal steg
    t_n = t_min:h:t_max; %Alla tidssteg
    carDistanceBrake = [75:75:75*M]; % Bilarnas avstånd vid t_min för inbromsning
    carDistanceAcc = [10:10:10*M];%Bilarnas avstånd vid t_min för acceleration
    iterations = 2; 
    
    %Meny för att välja olika funktioner att "execute"
    if chooseProgram == 1
        carPlotter(d_max, v_max, h, carDistanceBrake, M, t_n, g)
    elseif chooseProgram == 2
        carPlotter (d_max, v_max, h, carDistanceAcc, M, t_n, v_max)
    elseif chooseProgram == 3
        carPartC(d_max, v_max, h, M, carDistanceAcc,N,v_max)
    elseif chooseProgram == 4
        fixedPointIteration(g,N, M, h, carDistanceBrake,iterations)
    elseif chooseProgram == 5
        implicitEulerStep(g,h,M, carDistanceBrake, t_n, N)
    elseif chooseProgram == 6
        diffImpEulerFixedPoint(g,h,M, t_max, carDistanceBrake, t_n, N)
    elseif chooseProgram == 7
        carPartA ()
    end
end

function carPartA () %Funktion som plottar upg a) 
N = 400;
P = zeros(1,N)
x = -100
    for k = 1:N
        P(k) = velocity(x)
        x = x + 1;
    end
    plot (-100:N-101, P)
end
    

function carPlotter(d_max, v_max,h,X, M, t_n, g)%Funktionen plottar bilens position vid inbroms och acc
    hold on;
    for n = t_n %n är iterationstalet
        plot(n, X, ".")
        X = ForwEulerStep(X, h,d_max, v_max, g, M); %Kallar på funktion step 
    end
end
function nextX = ForwEulerStep(X, h, d_max, v_max,g, M) %Euler för ett steg och för alla steg
    nextX = zeros(1,M);
    for i = M:-1:1
        if i == M
            nextX(i) = X(i)+ h*g;
        else
            nextX(i) = X(i) + h*velocity(X(i+1)-X(i));
        end
    end
end
    
%del c)
function carPartC(d_max, v_max, h, M, X, N, g) %Här kollar vi när bilen accelerar, kan även undersöka när den bromsar in
    x = zeros(N, M);
    for i = 1:1:N
        x(i,:) = X; %För varje iteration läggs X till i matrisen
        X = ForwEulerStep(X, h, d_max, v_max,g, M);
        
    end
    
    for n=1:N    %Från uppgift c) lydelsen 
    plot(x(n,:),zeros(1,M),'r*');
    axis([0 1000 -1 1])
    drawnow
    pause(h)
    end
end

%Uppgift g)
function final_x = fixedPointIteration(g, N, M, h, x_start, p)
    X(:,1) = x_start;
    for n = 2:N
        X(M,n) = X(M,n-1) + h*g;
        for i = M-1:-1:1 %Går igenom bilarna från bil M-1 till bil 1
            y_new = 0;
            x_new = 0;
            z=0;
            while p > z 
                X(i, n-1);
                X(i+1, n);
                y_new = X(i,n-1) + h*velocity(X(i+1,n) - x_new);

                x_new = y_new;
                z = z+1;
            end
            X(i,n) = y_new;
        
        end
    end
    final_x = X(1,N)
    plot(1:N,X)
end
%Uppgift h)
function diffImpEulerFixedPoint(g,h,M, t_max, x_start, t_n, N)
    examine_iterations = 20;
    diff = zeros(1,examine_iterations);
    
    impEulerValue = implicitEulerStep(g,h,M, x_start, t_n, N);
    for p=1:1:examine_iterations
        diff(p) = abs(impEulerValue - fixedPointIteration(g,N, M, h, x_start,p));
    end
   
    d=1:1:examine_iterations;
    semilogy(d, diff, "*")%Logaritmisk skala för plot och antalet iterationer
end
%Implicit Euler Method, position=x
function final_x = implicitEulerStep(g,h,M, carDistanceBrake, t_n, N);
    x=t_n;
    x_matrix = zeros(M,N);
    x_matrix(:,1) = carDistanceBrake;
    for n = 1:N-1
        x_matrix(M,n+1) = x_matrix(M,n)+h*g;
        for i = (M-1):-1:1
           x_matrix(i, n+1) = (h*x_matrix(i+1, n+1)+ 3*x_matrix(i,n))/(h+3);
           if ((x_matrix(i+1,n+1)-x_matrix(i, n+1)) >=75)
               x_matrix(i,n+1) = x_matrix(i,n)+25*h;
           end
        end
    end
    final_x = x_matrix(1,N);
end