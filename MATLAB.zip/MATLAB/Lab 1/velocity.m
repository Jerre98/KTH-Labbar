function y = velocity(x)
    d_max = 75;
    v_max = 25;
    if d_max < x
        y = v_max;
    elseif x<0
        y = 0;
    else 
        y = (v_max/d_max)*x;
    end
    
end
    
    
    
    
 