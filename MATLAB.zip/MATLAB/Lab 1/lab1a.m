%Variabler
x = [0:1:150]


figure; hold on
for i = x
    y = velocity(i)
    plot(i, y, '.')
    
end