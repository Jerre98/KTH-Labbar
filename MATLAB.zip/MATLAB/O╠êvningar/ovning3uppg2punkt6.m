%Initial Values
format long
x0 = 1.5;
tol = 10^(-10);
P = @(x) (4*x^4-7*x^3+5.5*x^2+27.5*x-50);
dP = @(x) (16*x^3-21*x^2+11*x+27.5);

%Newtons metod
err = tol + 1;
x = x0;
while err > tol
    x_old = x;   %Sparar det gamla värdet först innan man börjar, har något att jämföra med
    x = x-P(x)/dP(x);
    err = abs(x-x_old);
end
