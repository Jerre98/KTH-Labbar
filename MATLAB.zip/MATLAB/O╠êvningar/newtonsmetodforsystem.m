% Initial Values
tol = 10^(-5);
F = @(x, y) [10*x - 2*y +x^3; x + 10*y + 5*y^2 -3];
J = @(x, y) [10+3*x^2, -2; 1, 10+10*y];
X0 = [0.06;0.03];



% Newtons Metod
err = tol + 1;
X = X0; 
while err>tol
    X_old = X;
    X = X - J(X(1), X(2))\F(X(1), X(2));
    err = norm(X-X_old);
end
    
    