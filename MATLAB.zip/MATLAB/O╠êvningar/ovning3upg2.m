%Initial values
format long
a = 3;
tol = 10^(-10);
f = @(x) x*log(a) - a*log(x)
df = @(x) log (a) - a/x;
x0 = 1;


% Newtons metod
err = tol +1;
x=x0;
while err > tol
    x_old = x;
    x= x - f(x) / df(x)
    err = abs(x-x_old)
end
