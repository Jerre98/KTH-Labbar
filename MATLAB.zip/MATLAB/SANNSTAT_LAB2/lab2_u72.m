%% Del 2 - multipel linj�r regressionsmodell
load birth.dat 
barn_vikt = birth(:, 3);

moder_vikt = birth(:,15);
moder_rok = birth(:,20) == 3;
moder_alkohol = birth(:, 26) == 2;

w = barn_vikt;
A = [ones(length(barn_vikt),1), moder_vikt, moder_rok, moder_alkohol];

B = regress(w,A);

f = B(1) + B(2)*moder_vikt + B(3)*moder_rok + B(4)*moder_alkohol;

res =  A*B - barn_vikt;
subplot(2,1,1), normplot(res)
subplot(2,1,2), hist(res)


[b,bint,r,rint,stats] = regress(w,A);
stats

bint 
%De som g�r f�rbi nollan inte signifikant
%De som INTE g�r f�rbi nollan �r signifikant (ex alkohol) 



