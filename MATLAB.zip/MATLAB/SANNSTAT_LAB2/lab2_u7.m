%% Problem 7: 


% Del 1 - enkel linj�r regressionsmodell
load birth.dat 

moder_langd = birth(:,16);
barn_vikt = birth(:, 3);

figure(1)
subplot(2,1,1)
scatter(moder_langd, barn_vikt)

w = barn_vikt ;
A = [ones(length(moder_langd),1), moder_langd];
B = regress(w,A) ;

f = B(1) + B(2)*moder_langd;

subplot(2,1,2)
plot(moder_langd,f) 









