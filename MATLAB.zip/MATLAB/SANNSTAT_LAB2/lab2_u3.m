clc
clear all 
close all 
%% Problem 3: Konfidensintervall for Rayleighfordelning
y=load ('wave_data.dat')
%Vi ser fr�n tv�an att minsta kvadrat gav b�st resultat. D�rav anv�nds MK i
%denna uppgift 

subplot(2,1,1), plot(y(1:100))
subplot(2,1,2), hist_density(y)
hold on 
%% Problem 3: Konfidensintervall (forts.)
%Vi saknar spridning och standardavvikelse, ber�knas nedan. Vi har tagit
%MK-skattning, d� denna gav b�st resultat tidare (2)

my_est = mean(y)*sqrt(2/pi) 
n = length(y); %antal m�tningar
s = sqrt((1/(n-1))*sum((y-my_est).^2)); %spridningsm�tt 
d = s*sqrt(2/pi)/sqrt(n); %standardavikelse formel 

%norminv(1-alpfa/2) med alpha 0.05 ger 1.96 
lower_bound = my_est-d*1.96 %1.96 �r ett tabellv�rde f�r 95% konfidensgrad, hittas �ven i uppg 1, ger samma v�rde. 
upper_bound = my_est+d*1.96 %vi rtar h�nsyn till diffen konfidensgrad

plot (lower_bound, 0,  'r*')
plot (upper_bound, 0,  'g*')

plot(0:0.1:6, raylpdf(0:0.1:6, my_est), 'r') %T�thetsfunktionen

%Diagrammet visar att de flesta m�tningarna ligger kring 1 
