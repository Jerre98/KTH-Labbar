%% Problem 4: Fordelningar av givna data
load birth.dat
x = birth(birth(:, 26) < 2, 3);
y = birth(birth(:, 26) == 2, 3);

iD = length(x) %Antalet icke-drickare
D = length(y) %Antalet drickare


%% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,1), boxplot(x),
axis([0 2 500 5000])
subplot(2,2,2), boxplot(y),
axis([0 2 500 5000])

%% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,3:4), ksdensity(x),
hold on
[fy, ty] = ksdensity(y);
plot(ty, fy, 'r')
hold off

