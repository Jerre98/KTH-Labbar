%% Problem 1: Simulering av konfidensintervall
clc, clear all, clf

% Parametrar:
n = 25; %Antal m�tningar
mu = 2; %V�ntevardet
sigma = 1; %Standardavvikelsen
alpha = 0.05;
%Simulerar n observationer f�r varje intervall

x = normrnd(mu, sigma,n,100); %n x 100 matris med v�rden
%Skattar mu med medelvardet
xbar = mean(x); %vektor med 100 medelvarden.
%Beraknar de undre och ovre granserna
undre = xbar - norminv(1-alpha/2)*sigma/sqrt(n);
ovre = xbar + norminv(1-alpha/2)*sigma/sqrt(n);

% Problem 1: Simulering av konfidensintervall (forts.)
% Ritar upp alla intervall
figure(1)
hold on
for k=1:100
    if ovre(k) < mu % Rodmarkerar intervall som missar mu
        plot([undre(k) ovre(k)],[k k],'r')
    elseif undre(k) > mu
        plot([undre(k) ovre(k)],[k k],'r')
    else
        plot([undre(k) ovre(k)],[k k],'b')
    end
end

b1 = min(xbar - norminv(1 - alpha/2)*sigma/sqrt(n));
b2 = max(xbar + norminv(1 - alpha/2)*sigma/sqrt(n));
axis([b1 b2 0 101]) %Tar bort outnyttjat utrymme i figuren
%Ritar ut det sanna vardet
plot([mu mu],[0 101],'g')
title('1.1 Simulering av konfidensintervall')
hold off


%% Problem 2: Maximum likelihood/Minsta kvadrat
clc, clear all, clf

M = 1e4;
b = 4;
x = raylrnd(b, M, 1); % returnerar slumpm�ssig array fr�n Rayleighf�rdelning  
hist_density(x, 40)
hold on

est_ml = sqrt(sum(x.^2)/(2*(length(x)))); % v�r ML-skattning 
est_mk = sum(x)*(sqrt(2/pi)/length(x)); % v�r MK skattning
figure(1)
plot(est_ml, 0, 'r*')
plot(est_mk, 0, 'g*')
plot(b, 0, 'ro')
title('2.1 F�rdelningsfunktion med skattning') 
hold on

% Problem 2: Maximum likelihood/Minsta kvadrat (forts.)
plot(0:0.1:20, raylpdf(0:0.1:20, est_ml), 'r')
hold off

%% Problem 3: Konfidensintervall for Rayleighfordelning
clc, clear all, clf
y = load ("wave_data.dat");
figure(1)
subplot(2,1,1), plot(y(1:100)) %�ndring fr�n y(1:100)-> y(1:end) f�r att se hela signalen
title('3.1 Rayleighf�rdelad signal')
subplot(2,1,2), hist_density(y)

% Problem 3: Konfidensintervall (forts.)
lambda_alpha=1.96;
est = mean(y)*sqrt(2/pi); %Utr�kning av MK skattningen (fr�n f�rberedelseuppg)
n = length(y);
s = sqrt(sum((y - mean(y)).^2)/(n-1)); %Stickprovsstandardavvikelsen
D = s/sqrt(n); %f�r ut standardavvikelsen
lower_bound = est - lambda_alpha*D; % alfa = arean per sida = 0.025(halva 5%)--> lambda 1.96
upper_bound = est + lambda_alpha*D; % Konfidensintervall(^/v).

hold on
plot(lower_bound, 0, 'g*')
plot(upper_bound, 0, 'g*')
plot(est, 0, 'r*')


% Problem 3: Konfidensintervall (forts.)
plot(0:0.1:6, raylpdf(0:0.1:6, est), 'r')
title('3.2 T�thetsfunktion med skattning')
hold off

%% Problem 4: Fordelningar av givna data
clc, clear all, clf
load birth.dat

b_vikt = birth(:,3); % barnets f�delsevikt
alder = birth(:,4); % moderns �lder
langd = birth(:,16); % moderns l�ngd
m_vikt = birth(:,15); % moderns vikt

figure(1),
subplot(2,2,1), hist_density(b_vikt), title('4.1 Barnets f�delsevikt')
subplot(2,2,2), hist_density(alder), title('4.2 Moderns �lder')
subplot(2,2,3), hist_density(langd), title('4.3 Moderns l�ngd') 
subplot(2,2,4), hist_density(m_vikt), title('4.4 Moderns vikt') 

%% 
% moderns r�kvanor och barnets vikt
x = birth(birth(:, 20) < 3, 3); 
y = birth(birth(:, 20) == 3, 3);
%L�g f�delsevikt < 2500g
%Mycket l�g f�delsevikt < 1500g
%Extremt l�g f�delsevikt < 1000g
length(x) % = antalet som inte r�ker eller slutat r�ka 
length(y) % = antalet som r�ker

% Problem 4: Fordelningar av givna data (forts.)
figure(1)
subplot(2,2,1), boxplot(x),
axis([0 2 500 5000])
title('4.5 Icke-r�kare')
subplot(2,2,2), boxplot(y),
axis([0 2 500 5000])
title('4.6 R�kare')

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,3:4), ksdensity(x),
title('4.7 J�mf�relse mellan r�kare och icke-r�kare')
hold on
[fy, ty] = ksdensity(y);
plot(ty, fy, 'r')
hold off


%% Problem 4 forts uppg: En annan kategori i datan: Fordelningar av givna data - alkohol. 

% nu anv�nder vi oss av data g�llande (alkohol)
% moderns alkoholvanor och barnets vikt
x = birth(birth(:, 26) < 2, 3);  
y = birth(birth(:, 26) == 2, 3); 

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,1), boxplot(x),
axis([0 2 500 5000])
title('4.8 Icke-drickare')
subplot(2,2,2), boxplot(y),
axis([0 2 500 5000])
title('4.9 Drickare')

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,3:4), ksdensity(x),
hold on
[fy, ty] = ksdensity(y);
plot(ty, fy, 'r')
title("4.10 Dricker resp. dricker inte under graviditet")
hold off


%% Problem 5 - Test av normalitet
clc, clear all, clf
load birth.dat

x1 = birth(:,3); % barnets f�delsevikt
x2 = birth(:,4); % moderns �lder
x3 = birth(:,16); % moderns l�ngd
x4 = birth(:,15); % moderns vikt


% normplot visar en normelf�rdelade graf.
figure(1),
subplot(2,1,1), normplot(x1), title('Barnets f�delsevikt')
subplot(2,1,2), normplot(x2), title('Moderns �lder')
figure(2)
subplot(2,1,1), normplot(x3), title('Moderns l�ngd') 
subplot(2,1,2), normplot(x4), title('Moderns vikt') 
 
Jarque_Bera_test1 = jbtest(x1)
Jarque_Bera_test2 = jbtest(x2)
Jarque_Bera_test3 = jbtest(x3)
Jarque_Bera_test4 = jbtest(x4)

% H = 0 indikerar att data �r normalf�rdelat 
% H = 1 indikerar att nollhypotesen kan avvisas p� en signigikansniv� p� 5%

%% Problem 6: Regression
clc, clear all, clf
load moore.dat
%Moore: transistorer per yta

x_time = moore(:,1) % �rtal
y = moore(:,2) % transistorer per yta
X = [ones(size(x_time)) x_time] %G�r om till matris med kolumn av ettor och 
% �rtalen i andra kolumnen.
w = log(y)
[beta_hat,bint,r,rint,stats] = regress(w,X);
linreg = X*beta_hat;


antal = @(x) beta_hat(1) + beta_hat(2)*x %beta_hat1 �r beta0 och beta_hat2 �r beta1

%Skatter med linear regression vad det �r i 2025
antal_2025 = exp(antal(2025)) % = 1.4*10^8 

%% Problem 6:residualen 
res = X*beta_hat - w; %residualen
figure(1)
subplot(2,1,1), normplot(res)
subplot(2,1,2), hist(res)

figure(2)
subplot(1,1,1), plot(x_time,exp(linreg))
title("Skattad modell f�r resistorer")
figure(3)
subplot(1,1,1), plot(x_time,exp(w))
title("Resistorer per ytenhet")


%% Problem 7 - Multipel linj�r regression - enkel variant
clc, clear all, clf
load birth.dat

%enkel linj�r regressionsmodell 
%Modellen beskriver hur barnets f�delsevikt beror p� moderns l�ngd.
mother_length = birth(:,16); % moderns l�ngd
birth_weight = birth(:,3); % F�delsevikt
X = [ones(size(mother_length)) mother_length]; 
beta_hat = regress(birth_weight,X);
lin_reg_model = X*beta_hat; %linreg
figure(1)
subplot(2,1,1),plot(mother_length,birth_weight, 'ob')
title('7.1 Moderns l�ngd kontra barnets vikt')
subplot(2,1,2), plot(mother_length, lin_reg_model, '-b')
title('7.2 Moderns l�ngd kontra linj�r regressionsmodell')

%% Multipel linj�r regression - multipel variant
format short g

%Barnets f�delsevikt
child_weight = birth(:,3); 

% moderns vikt
mother_weight = birth(:,15); 

%R�kvanor
mother_smoke = birth(:, 20);
mother_smoke(mother_smoke < 3)= 0; %Icke-r�kare
mother_smoke(mother_smoke == 3)=1; %R�kare

%Alkohol
mother_alcohol = birth(:, 26); 
mother_alcohol(mother_alcohol == 2) = 0; %2= Dricker


X = [ones(length(child_weight),1), mother_weight, mother_smoke, mother_alcohol] 

%M�ste ta bort rader i matrisen ovan som inneh�ller NaN....
[row, column] = find(isnan(X));
for n = row
    X(n,:)=[];
    child_weight(n)=[];
end

[beta_hat bint] = regress(child_weight,X); % f�r fram lutning de olika p�verkar 

multi_reg = X*beta_hat - child_weight; %residualen

KI_mother_weight = -((bint(2,1)) - (bint(2,2)))
KI_mother_smoke = -((bint(3,1)) - (bint(3,2)))
KI_mother_alcohol = -((bint(4,1)) - (bint(4,2)))

figure(1)
subplot(2,1,1), normplot(multi_reg)
title('7.3 Residual mot normalf�rdelning')
subplot(2,1,2), hist(multi_reg)
title('7.4 Histogrammet f�r residualen')


