%% Problem 1: Simulering av konfidensintervall
clc, clear all, clf

% Parametrar:
n = 25; %Antal m�tningar
mu = 2; %V�ntevardet
sigma = 1; %Standardavvikelsen
alpha = 0.05;
%Simulerar n observationer f�r varje intervall

x = normrnd(mu, sigma,n,100); %n x 100 matris med v�rden
%Skattar mu med medelvardet
xbar = mean(x); %vektor med 100 medelvarden.
%Beraknar de undre och ovre granserna
undre = xbar - norminv(1-alpha/2)*sigma/sqrt(n);
ovre = xbar + norminv(1-alpha/2)*sigma/sqrt(n);

% Hur m�nga av dessa intervall
% kan f�rv�ntas inneh�lla det sanna v�rdet p� ?

% SVAR:
% 95% kan f�rv�ntas inneh�lla det sanna v�rdet

% Problem 1: Simulering av konfidensintervall (forts.)
% Ritar upp alla intervall
figure(1)
hold on
for k=1:100
    if ovre(k) < mu % Rodmarkerar intervall som missar mu
        plot([undre(k) ovre(k)],[k k],'r')
    elseif undre(k) > mu
        plot([undre(k) ovre(k)],[k k],'r')
    else
        plot([undre(k) ovre(k)],[k k],'b')
    end
end
%b1 och b2 ar bara till for att figuren ska se snygg ut.
b1 = min(xbar - norminv(1 - alpha/2)*sigma/sqrt(n));
b2 = max(xbar + norminv(1 - alpha/2)*sigma/sqrt(n));
axis([b1 b2 0 101]) %Tar bort outnyttjat utrymme i figuren
%Ritar ut det sanna vardet
plot([mu mu],[0 101],'g')
title('1.1 Simulering av konfidensintervall')
hold off

% SVAR: 
% Pga 95% intervall b�r vi f� 5 antal r�da str�cken
% de horisontella str�cken: beskriver utfall, ca 95 utfall borde inneh�lla
% det sanna v�rdet (alts� bl�a)
% Vertikala str�cket: v�ntev�rdet
% Varierer my: �ndrar v�ntev�rdet
% Varierer sigma: �ndrar intervall
% Varierer alpha: �ker alpha-> �ker antal r�da
% Varierer n: �kar n-> mindre spridning, mer tillf�rlitligt

%% Problem 2: Maximum likelihood/Minsta kvadrat
clc, clear all, clf

M = 1e4;
b = 4;
x = raylrnd(b, M, 1); % returnerar slumpm�ssig array fr�n Rayleighf�rdelning  
hist_density(x, 40)
hold on

est_ml = sqrt(sum(x.^2)/(2*(length(x)))); % v�r ML-skattning 
est_mk = mean(x)*sqrt(2/pi); % v�r MK skattning, d�r mean() = vektorn
figure(1)
plot(est_ml, 0, 'r*')
plot(est_mk, 0, 'g*')
plot(b, 0, 'ro')
title('2.1 F�rdelningsfunktion med skattning') 
hold on

% Problem 2: Maximum likelihood/Minsta kvadrat (forts.)
plot(0:0.1:20, raylpdf(0:0.1:20, est_ml), 'r')
hold off

% SVAR: 
% Ja skattningen ser bra ut, pga den r�da linjen och det bl�a st�mmer �verens
% R�da �r t�thetsfunktionen, bl�a �r skattningen.
%% Problem 3: Konfidensintervall for Rayleighfordelning
clc, clear all, clf
y = load ("wave_data.dat");
figure(1)
subplot(2,1,1), plot(y(1:100)) %�ndring fr�n y(1:100)-> y(1:end) f�r att se hela signalen
title('3.1 Rayleighf�rdelad signal')
subplot(2,1,2), hist_density(y)

% Problem 3: Konfidensintervall (forts.)
lambda_alpha=1.96;
est = mean(y)*sqrt(2/pi); %Utr�kning av MK skattningen (fr�n f�rberedelseuppg)
n = length(y);
s = sqrt(sum((y - mean(y)).^2)/(n-1)); %Stickprovsstandardavvikelsen
D = s/sqrt(n); %f�r ut standardavvikelsen
lower_bound = est - lambda_alpha*D; % alfa = arean per sida = 0.025(halva 5%)--> lambda 1.96
upper_bound = est + lambda_alpha*D; % Konfidensintervall(^/v).

hold on %G�r s� att plotten h�lls kvar
plot(lower_bound, 0, 'g*')
plot(upper_bound, 0, 'g*')
plot(est, 0, 'r*')


% Problem 3: Konfidensintervall (forts.)
plot(0:0.1:6, raylpdf(0:0.1:6, est), 'r')
title('3.2 T�thetsfunktion med skattning')
hold off

% Ser f�rdelningen ut att passa bra?

% SVAR: 
% Ja skattningen ser bra ut, pga den r�da linjen och det bl�a st�mmer �verens

%% Problem 4: Fordelningar av givna data
clc, clear all, clf
load birth.dat

b_vikt = birth(:,3); % barnets f�delsevikt
alder = birth(:,4); % moderns �lder
langd = birth(:,16); % moderns l�ngd
m_vikt = birth(:,15); % moderns vikt

% normplot visar en normalf�rdelade graf.
figure(1),
subplot(2,2,1), hist_density(b_vikt), title('4.1 Barnets f�delsevikt')
subplot(2,2,2), hist_density(alder), title('4.2 Moderns �lder')
subplot(2,2,3), hist_density(langd), title('4.3 Moderns l�ngd') 
subplot(2,2,4), hist_density(m_vikt), title('4.4 Moderns vikt') 

%% 
% moderns r�kvanor och barnets vikt
x = birth(birth(:, 20) < 3, 3); 
y = birth(birth(:, 20) == 3, 3);
%L�g f�delsevikt < 2500g
%Mycket l�g f�delsevikt < 1500g
%Extremt l�g f�delsevikt < 1000g
length(x) % = antalet som inte r�ker eller slutat r�ka 
length(y) % = antalet som r�ker

% Problem 4: Fordelningar av givna data (forts.)
figure(1)
subplot(2,2,1), boxplot(x),
axis([0 2 500 5000])
title('4.5 Icke-r�kare')
subplot(2,2,2), boxplot(y),
axis([0 2 500 5000])
title('4.6 R�kare')

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,3:4), ksdensity(x),
title('4.7 J�mf�relse mellan r�kare och icke-r�kare')
hold on
[fy, ty] = ksdensity(y);
plot(ty, fy, 'r')
hold off

% SVAR:
% boxplot: i boxen finns mest v�rde
% boxen har 25% i varje del av boxen (totalt 50% av utfallen)
% V�nster figur: inte r�ker
% H�ger figur: r�ker
% Det som denna figur visar �r hur vikten �r f�rdelad
% Mitten av boxsen �r medianen
% Svarta strecket: kvantiler(lambdaalfa/2)
% r�da streck: outliers 
% Grafen: t�thetsf�rdelningen av de olika datan
% den r�da grafen �r y, dvs r�kare

% Inget tydligt samband mellan barns vikt och mammor som r�ker?

%% Problem 4 forts uppg: En annan kategori i datan: Fordelningar av givna data - alkohol. 

% nu anv�nder vi oss av data g�llande (alkohol)
% moderns alkoholvanor och barnets vikt
x = birth(birth(:, 26) < 2, 3);  
y = birth(birth(:, 26) == 2, 3); 

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,1), boxplot(x),
axis([0 2 500 5000])
title('4.8 Icke-drickare')
subplot(2,2,2), boxplot(y),
axis([0 2 500 5000])
title('4.9 Drickare')

% Problem 4: Fordelningar av givna data (forts.)
subplot(2,2,3:4), ksdensity(x),
hold on
[fy, ty] = ksdensity(y);
plot(ty, fy, 'r')
title("4.10 Dricker resp. dricker inte under graviditet")
hold off

% V�nster figur: icke-drickare
% H�ger figur: dricker
% Det som denna figur visar �r hur vikten �r f�rdelad

% Inget tydligt samband mellam barns vikt och mammor som dricker?

%% Problem 5 - Test av normalitet
clc, clear all, clf
load birth.dat

x = birth(:,3); % barnets f�delsevikt
y = birth(:,4); % moderns �lder
w = birth(:,16); % moderns l�ngd
z = birth(:,15); % moderns vikt


% normplot visar en normelf�rdelade graf.
figure(1),
subplot(2,1,1), qqplot(x), title('Barnets f�delsevikt')
subplot(2,1,2), qqplot(y), title('Moderns �lder')
figure(2)
subplot(2,1,1), qqplot(w), title('Moderns l�ngd') 
subplot(2,1,2), qqplot(z), title('Moderns vikt') 

% kan dessa s�gas vara normalf�rdelade och om inte p� vilket
% s�tt de olika variablerna avviker fr�n normalf�rdelning slumpvariabler?

% SVAR: Barnets f�delsevikt och moderns vikt verkar vara normalf�rdelad,
% men inte moderns �lder. 

Jarque_Bera_test_x = jbtest(x)
Jarque_Bera_test_y = jbtest(y)
Jarque_Bera_test_w = jbtest(w)
Jarque_Bera_test_z = jbtest(z)

% H = 0 indikerar att data �r normalf�rdelat 
% H = 1 indikerar att nollhypotesen kan avvisas p� en signigikansniv� p� 5%
% vilket inneb�r att alla variabler utom moderns l�ngd inte �r normalf�rdelad.

%% Problem 6: Regression
clc, clear all, clf
load moore.dat
%Moore: transistorer per yta

xtime = moore(:,1) % �rtal
y = moore(:,2) % transistorer per yta
X = [ones(size(xtime)) xtime] %G�r om till matris med kolumn av ettor och 
% �rtalen i andra kolumnen.
y1 = log(y)
[beta_hat,bint,r,rint,stats] = regress(y1,X);
stats(1) % = 0.95862 --> ska vara n�ra 1 f�r att vara p�litlig
lin_reg_model = X*beta_hat;

figure(1)
plot(xtime,y1) %xtime: givet i filen, det �r x-v�rden i filen
hold on
plot(xtime,lin_reg_model, 'r')
hold on

antal = @(x) beta_hat(1) + beta_hat(2)*x %beta_hat1 �r beta0 och beta_hat2 �r beta1

%Skatter med linear regression vad det �r i 2025
antal_2025 = exp(antal(2025)) % = 1.4*10^8 

%% Problem 6:residualen 
linreg_res = X*beta_hat - y1; %residualen
figure(1)
subplot(2,1,1), normplot(linreg_res) % ser rimligt ut
subplot(2,1,2), hist(linreg_res) % rimligt ut att de flesta �r mellan -1:1

%% Problem 7 - Multipel linj�r regression - enkel variant
clc, clear all, clf
load birth.dat

%enkel linj�r regressionsmodell 
%Modellen beskriver hur barnets f�delsevikt beror p� moderns l�ngd.
mother_length = birth(:,16); % moderns l�ngd
birth_weight = birth(:,3); % F�delsevikt
X = [ones(size(mother_length)) mother_length]; 
beta_hat = regress(birth_weight,X);
lin_reg_model = X*beta_hat; %linreg
figure(1)
subplot(2,1,1),plot(mother_length,birth_weight, 'ob')
title('7.1 Moderns l�ngd kontra moderns vikt')
subplot(2,1,2), plot(mother_length, lin_reg_model, '-b')
title('7.2 Moderns l�ngd kontra linj�r regressionsmodell')

%% Multipel linj�r regression - multipel variant
format short g

%Barnets f�delsevikt
child_weight = birth(:,3); 

% moderns vikt, r�kvanor, alkohol
mother_weight = birth(:,15); 
mother_smoke = birth(:, 20) == 3; 
mother_alcohol = birth(:, 26) == 2; 


X = [ones(length(child_weight),1), mother_weight, mother_smoke, mother_alcohol]; 
[beta_hat bint] = regress(child_weight,X); % f�r fram lutning de olika p�verkar 

% vikten har en typ tydlig p�verkan, inget annat

multi_reg = X*beta_hat - child_weight; %residualen
figure(1)
subplot(2,1,1), normplot(multi_reg) % ser rimligt ut, ganska normalf�rdelat
title('7.3 Residual mot normalf�rdelning')
subplot(2,1,2), hist(multi_reg)
title('7.4 Histogrammet f�r residualen')
