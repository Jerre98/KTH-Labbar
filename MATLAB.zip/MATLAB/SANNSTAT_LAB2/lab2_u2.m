%% Problem 2: Maximum likelihood/Minsta kvadrat
M = 1e4;
b = 4;
x = raylrnd(b, M, 1);

hist_density(x, 40)
hold on
my_est_ml = sqrt(1/2)*mean(x); % Skriv in din ML-skattning har
my_est_mk = mean(x)/sqrt(pi/2); % Skriv in din MK-skattning har
plot(my_est_ml, 0,'r*')
hold on
plot(my_est_mk, 0, 'g*')
hold on
plot(b, 0, 'ro')
hold on 

%% Problem 2: Maximum likelihood/Minsta kvadrat (forts.)
plot(0:0.1:10, raylpdf(0:0.1:10, my_est_mk), 'r')
