N=1e6;
x=rand(N,1);
sum=0;
for n=1:N
    sum=sum+x(n)^4;
end
disp(sum/N)