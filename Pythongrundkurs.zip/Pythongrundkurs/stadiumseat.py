# Stadium seating

def uträkning_totalpris(A,B,C):
    return A*290 + B*220 + C*140

svar = input ('Hur många biljetter har sålts totalt av typ A?')
AntalA = int (svar)

svar = input ('Hur många biljetter har sålts totalt av typ B?')
AntalB = int (svar)

svar = input('Hur många biljetter har sålts totalt av typ C?')
AntalC = int (svar)

print ('Det totala antalet biljetter sålda är', uträkning_totalpris(AntalA,AntalB,AntalC))
