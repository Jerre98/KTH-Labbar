# Kilometer konverterare
# Miles = Kilometer * 0.6214
def kilometerkonverterare (km):
    return km*0.6214


svar = input ('Ange en distans i km')

km = float (svar)

print ('Distansen i miles är', kilometerkonverterare(km))
     

# Stadium seating

def sittplatskategori(A,B,C):
    return A*290 + B*220 + C*140

svar = input ('Hur många biljetter har sålts totalt av typ A?')
A = int (svar)

svar = input ('Hur många biljetter har sålts totalt av typ B?')
B = int (svar)

svar = input('Hur många biljetter har sålts totalt av typ C?')
C = int (svar)

print ('Det totala antalet biljetter sålda är', sittplatskategori(A,B,C))

    
    
