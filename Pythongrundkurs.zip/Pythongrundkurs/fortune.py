#Fortune cookie sumulator

import random
dir(random)
print("\tWelcome to the Fortune Cookie program!")

one = "Viktor tar en shot"
two = "Jacob sveper halva sin öl"
three = "Jesper tar en shot eller sveper sin öl"
four = "Försten som säger öl - får svepa en öl."
five = "nummer 5, får ge 5 klunkar."
    

#choosing one randomly
cookie = random.randint (1,5)
if cookie == 1:
       print(one)
elif cookie == 2:
    print(two)
elif cookie ==3:
    print (three)
elif cookie == 4:
    print (four)
elif cookie == 5:
    print(five)

input("\n\nPress the enter key to exit.") 


    

