#Väderprogram 1 Jesper Lantz Lab 3

#interface
månader = ("Januari", "Februari", "Mars", "April", "Maj", "Juni", "Juli", "Augusti", "September", "Oktober", "November", "December")
def interface():
    summa=0
    högsta=0
    lägsta=0
    val = ""
    while val != "3":
        val = input ("""
        1. Mata in nederbörd månadsvis under ett år
        2. Se statistik för detta år
        3. Avsluta
        """)
    
        if val == "1":
            summa,högsta,lägsta = inmatning()
        elif val =="2":
            statistik(summa,högsta,lägsta)
        elif val == "3":
            print("Du har valt att avsluta ditt program")
     
        else:
            print("Fel val")
        #Upprepande av interface, tillkallar funk
    
#inmatning
def inmatning():
    högsta=0
    lägsta=0
    summa=0
    for s in månader:
        värde = float(input("Skriv in värde för månad:" + s))
        summa = summa+värde
        if högsta < värde or högsta == 0:
            högsta=värde
        if lägsta >värde or lägsta == 0:
            lägsta=värde
            
    #Upprepande av interface, tillkallar funk    
    return summa,högsta,lägsta
       

#statistik
def statistik(summa,högsta,lägsta):
    mvärde = summa/12
    print("Medelvärdet är:",mvärde)
    print("Högsta värdet är:",högsta)
    print("Lägsta värdet är:",lägsta)
    
    
    #Upprepande av interface, tillkallar funk
    


interface()


