"""
Fråga 1
import random
x=random.randrange(1,10) ### kod som saknas ###
print(x)


Fråga 2
svar = input('Ange ett flyttal')
x=float(svar)### kod som saknas ###
print(x)



Fråga 3
def firstWord(orden):
    orden.sort()
    return orden ### kod som saknas ###

svar = input('Ange ett godtyckligt antal ord som du separerar med mellanslag:').split()
print(firstWord(svar))

Fråga 4
def maxLenWord(orden):
    längst = ["adam", "cirkus"]### kod som saknas ###
    for ordet in orden:
        if len(ordet) > len(längst):
            längst = ordet
    return längst

svar = input('Ange ett godtyckligt antal ord som du separerar med mellanslag:').split()
print(maxLenWord(svar))


Fråga 5
def counter(text):
    d = dict()
    for tecken in text:
        if tecken in d.keys():
            d[tecken] += 1
        else:
            d[tecken]=1 ### kod som saknas ###
    return d

print(counter('tentamen'))


Fråga 6
s = 'tentamen'
vokaler = 'eyuioaåäö'
for tecken in s:### kod som saknas ###
    if tecken in vokaler:
        print('*', end = '')
    else:
        print(tecken, end = '')


Fråga 7

filnamn = input('Ange filens namn:')
try:
    f=open("testfil.txt")### kod som saknas ###
except FileNotFoundError:
    print('Filen existerar ej')

Fråga 8
class Hexaeder: # likt en kub fast olika x,y,z

    def __init__(self, x, y, z):
        self.x = x
        self.y = y
        self.z = z

    def volym(self):
        return self.x*self.y*self.z ### Kod som saknas ###

h = Hexaeder(1,2,3)
print(h.volym())



Fråga 9

class Prov:

    def __init__(self, pnr, namn):
        self.pnr = pnr
        self.poäng = [0] * 10 # en lista med poäng på resp fråga

    def setScore(self, questionNumber, score):
        self.poäng[questionNumber] = score

prov1 = Prov('121212-1212','Ada Adamsson')
prov1.poäng= [0]*9 + [2]*1### kod som saknas ###
print(prov1.poäng)


Fråga 10
class Fordon:

    def __init__(self, märke, regnr):
        self.märke = märke
        self.regnr = regnr
        self.påställd = False

    def ställPå(self):
        self.påställd = True
        
    def ställAv(self):
        self.påställd = False

f=Fordon("Volvo", "ABC123")### kod som saknas ###
f.ställPå()
print(f)
"""


















