
string_name = 'geeks FOR geeks'



print(string_name.capitalize())
