#context manager
(#Fördelen med context är att vi kan jobba med filen inuti
#när vi går ut ur blocket så stänger koden ner filen åt oss, istället
#för att göra det manuellt själv)
with open("test.txt", "r") as f:
    f_contents = f.readlines()
    print(f_contents)

print(f.closed)

