import random
random.randint (1,6)
random.randrange(6)+1
