def lasInSalar():
    d = dict()
    infil = open("salar.txt", "r")
    rader = infil.readlines()
    for rad in rader:
        raddelar = rad.split(":")
        d[raddelar[0]] = raddelar[1]
    return d
def interface():
    salar = lasInSalar()
    print("Välkommen till bokningssystemet")
    s = ""
    for key in salar.keys():
    #Hämtar alla keys ifrån vår dictionary
        s+= "" +key
    print("Lediga salar är:" + s)
    svar = input("Vilka salar vill du boka?")
    bokade = svar.split(" ")
    datorer = 0
    for sal in bokade:
        datorer+= salar[sal]
    print("Du har bokat,")
    for sal in bokade:
        print(sal, salar[salar], "datorer")
    print("Total:", datorer)
interface()

