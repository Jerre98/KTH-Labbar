#LAB 2  Jesper Lantz

# Kilometer konverterare 
# Miles = Kilometer * 0.6214
def kilometerkonverterare (km):
    return km*0.6214


svar = input ('Ange en distans i km')

km = float (svar)

print ('Distansen i miles är', kilometerkonverterare(km))


# Stadium seating
#Tre sittplats-kategorier
#Beräkna totalpriset

def uträkning_totalpris(A,B,C):
    return A*290 + B*220 + C*140

svar = input ('Hur många biljetter har sålts totalt av typ A?')
AntalA = int (svar)

svar = input ('Hur många biljetter har sålts totalt av typ B?')
AntalB = int (svar)

svar = input('Hur många biljetter har sålts totalt av typ C?')
AntalC = int (svar)

print ('Det totala antalet biljetter sålda är', uträkning_totalpris(AntalA,AntalB,AntalC))
