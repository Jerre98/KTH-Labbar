# funktionsexempel
import math

def cirkelarea (radie):
    
    
    
        
    

    
