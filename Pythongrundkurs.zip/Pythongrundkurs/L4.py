ListOne=[]



fråga=str(input("Vilken fil vill du öppna?"))
    
def funktion(f):
    OpenFileOne=open(f,"r")
    ReadFileOne=OpenFileOne.read()
    ListOne.append(ReadFileOne)

    return ListOne

funktion(fråga)
print(ListOne)
    
