def hash2(s):
    x = 0
    for i in range (len(s)):
        x = x + (ord(s[i])) -64
        
    return x
