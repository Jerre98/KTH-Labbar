class Pokemon:

    def __init__ (self, number, name, type1, type2, total, hp, attack, defense, spAtk, spDef, speed, generation, legendary)
    self.__number = number
    self.__name = name
    self.__type1 = type1
    self.__type2 = type2
    self.__total = total
    self.__hp = hp
    self.__attack = attack
    self.__defense = defense
    self.__spAtk = sp.Atk
    self.__spDef = sp.Def
    self.__speed = speed
    self.__generation = generation
    self.__legendary = legendary

    def __str__ (self):
        return 'Detta är en {self.name} pokemón' + 'med 

def test_pokemon (self, name):
    name1 = 'Tobias'
    name2 = 'Jesper'
    
print (name)
